package com.memoryassistant.daily.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val description: String? = null,
    val date: String, // Format: YYYY-MM-DD
    val time: String? = null, // Format: HH:mm
    val category: String,
    val priority: String = "medium", // "low", "medium", "high"
    val repeatFrequency: String = "none", // "none", "daily", "weekly", "monthly", "yearly"
    val repeatDayOfMonth: Int? = null,
    val notifyBefore: String = "at_time", // "none", "at_time", "15m", "1h", "1d"
    val status: String = "pending", // "pending", "completed", "postponed"
    val notes: String? = null,
    val completedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
