package com.memoryassistant.daily

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class MemoryAssistantApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Personal Memory Reminders",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Friendly notifications for tasks, daily reviews, and personal habits"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 200, 100, 200)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_ID = "memory_assistant_reminders"
    }
}
