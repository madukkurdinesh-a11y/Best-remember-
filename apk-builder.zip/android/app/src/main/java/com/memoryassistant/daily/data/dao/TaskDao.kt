package com.memoryassistant.daily.data.dao

import androidx.room.*
import com.memoryassistant.daily.data.model.TaskEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {

    @Query("SELECT * FROM tasks ORDER BY date ASC, time ASC")
    fun getAllTasks(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE date = :today AND status = 'pending' ORDER BY time ASC")
    fun getTodayPendingTasks(today: String): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE date < :today AND status = 'pending' ORDER BY date ASC")
    fun getOverdueTasks(today: String): Flow<List<TaskEntity>>

    @Query("SELECT COUNT(*) FROM tasks WHERE date = :today AND status = 'completed'")
    fun getTodayCompletedCount(today: String): Flow<Int>

    @Query("SELECT COUNT(*) FROM tasks WHERE date = :today AND status = 'pending'")
    fun getTodayPendingCount(today: String): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: TaskEntity)

    @Update
    suspend fun updateTask(task: TaskEntity)

    @Delete
    suspend fun deleteTask(task: TaskEntity)

    @Query("UPDATE tasks SET status = :status, completedAt = :completedAt, updatedAt = :updatedAt WHERE id = :taskId")
    suspend fun updateTaskStatus(taskId: String, status: String, completedAt: Long?, updatedAt: Long)
}
