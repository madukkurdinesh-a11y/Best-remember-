import React, { useState } from 'react';
import {
  Bell,
  Volume2,
  Vibrate,
  Clock,
  Globe,
  Sun,
  Moon,
  Database,
  Download,
  Upload,
  RotateCcw,
  Smartphone,
  ShieldCheck,
  Check,
  FileCode,
  Copy,
  AlertCircle,
  ExternalLink,
  PackageCheck,
  FolderArchive,
} from 'lucide-react';
import { UserSettings } from '../types';
import { storage } from '../services/storage';
import {
  playReminderChime,
  triggerVibration,
  requestNotificationPermission,
} from '../services/audioNotification';
import { ANDROID_PROJECT_FILES, INSTALLATION_GUIDE } from '../data/androidProjectCode';
import { downloadAndroidProjectZip } from '../services/zipExporter';

interface ScreenSettingsProps {
  settings: UserSettings;
  onUpdateSettings: (newSettings: UserSettings) => void;
  onDataRestored: () => void;
}

export const ScreenSettings: React.FC<ScreenSettingsProps> = ({
  settings,
  onUpdateSettings,
  onDataRestored,
}) => {
  const [copiedFile, setCopiedFile] = useState<string | null>(null);
  const [selectedFileIdx, setSelectedFileIdx] = useState(0);
  const [importStatus, setImportStatus] = useState<string | null>(null);
  const [showAndroidCode, setShowAndroidCode] = useState(true);
  const [isZipping, setIsZipping] = useState(false);

  const handleSoundTest = () => {
    playReminderChime();
    if (settings.vibrationEnabled) {
      triggerVibration([200, 100, 200]);
    }
  };

  const handleExportBackup = () => {
    const jsonStr = storage.exportData();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `daily-memory-assistant-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const res = storage.importData(content);
      setImportStatus(res.message);
      if (res.success) {
        onDataRestored();
      }
    };
    reader.readAsText(file);
  };

  const handleResetData = () => {
    if (window.confirm('Reset all tasks, notes, and preferences to initial sample data?')) {
      storage.resetAll();
      onDataRestored();
      setImportStatus('Data reset to default successfully.');
    }
  };

  const copyCode = (code: string, fileName: string) => {
    navigator.clipboard.writeText(code);
    setCopiedFile(fileName);
    setTimeout(() => setCopiedFile(null), 2000);
  };

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      await downloadAndroidProjectZip();
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="space-y-5 pb-24">
      {/* Title */}
      <div>
        <h3 className="font-bold text-base text-slate-900 dark:text-white">
          Assistant Settings & Preferences
        </h3>
        <p className="text-xs text-slate-500">
          Personalize review times, sound notifications, offline backup, and device reliability.
        </p>
      </div>

      {/* ANDROID NATIVE PROJECT & APK BUILD STATUS */}
      <div className="p-4 sm:p-5 rounded-3xl bg-indigo-50/70 dark:bg-indigo-950/40 border-2 border-indigo-200 dark:border-indigo-800 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center shrink-0 shadow-md shadow-indigo-600/20">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-sm sm:text-base text-slate-900 dark:text-white">
                Native Android Build & Project Bundle
              </h4>
              <p className="text-xs text-slate-500">
                Kotlin, Jetpack Compose, Room DB & assembleDebug task
              </p>
            </div>
          </div>

          <button
            onClick={handleDownloadZip}
            disabled={isZipping}
            className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md transition flex items-center justify-center gap-1.5 active:scale-95 disabled:opacity-50"
          >
            <FolderArchive className="w-4 h-4" />
            {isZipping ? 'Packaging...' : 'Download Project (.zip)'}
          </button>
        </div>

        {/* Honest Build Environment Status Card */}
        <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2 text-xs">
          <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 font-bold">
            <PackageCheck className="w-4 h-4 shrink-0" />
            <span>Gradle Configuration: Checked & Ready for "assembleDebug"</span>
          </div>
          <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
            All Gradle project files (<code className="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 font-mono text-[11px]">settings.gradle.kts</code>, <code className="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 font-mono text-[11px]">build.gradle.kts</code>, <code className="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 font-mono text-[11px]">app/build.gradle.kts</code>) have been verified with Java 17 and Android SDK 34 targets.
          </p>

          <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-800/60 text-amber-900 dark:text-amber-200 space-y-1">
            <div className="flex items-center gap-1.5 font-bold">
              <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
              <span>Environment Status & APK Generation Disclosure:</span>
            </div>
            <p className="text-[11px] leading-relaxed">
              This cloud environment is a sandboxed Linux/Node.js web container and does not contain the Java JDK or the Android SDK CLI toolchain. As required, <strong>we do not fabricate or claim an APK was generated</strong> where the compiler is absent.
            </p>
            <p className="text-[11px] leading-relaxed font-semibold">
              <strong>Your 2 Options to install on your Android phone right now:</strong>
            </p>
            <ol className="list-decimal pl-4 space-y-1 text-[11px]">
              <li>
                <strong>Instant (Recommended):</strong> Tap <strong>"Install App"</strong> in the top header on your Android Chrome browser. It installs instantly as a full standalone app with offline storage and sound notifications.
              </li>
              <li>
                <strong>Native APK:</strong> Tap <strong>"Download Project (.zip)"</strong> above, unzip, open in Android Studio on your computer, and run <code className="font-mono bg-amber-100 dark:bg-amber-900/60 px-1 rounded">./gradlew assembleDebug</code> to generate <code className="font-mono">app-debug.apk</code>.
              </li>
            </ol>
          </div>
        </div>

        {/* Source Code Explorer */}
        <div className="space-y-3 pt-1">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
              Browse Source Files ({ANDROID_PROJECT_FILES.length}):
            </span>
            <button
              onClick={() => setShowAndroidCode(!showAndroidCode)}
              className="text-xs text-indigo-600 dark:text-indigo-400 font-semibold hover:underline"
            >
              {showAndroidCode ? 'Collapse Code' : 'Expand Code'}
            </button>
          </div>

          {showAndroidCode && (
            <div className="space-y-3">
              {/* File Selector Tabs */}
              <div className="flex gap-1.5 overflow-x-auto no-scrollbar py-1">
                {ANDROID_PROJECT_FILES.map((f, i) => (
                  <button
                    key={f.path}
                    onClick={() => setSelectedFileIdx(i)}
                    className={`px-2.5 py-1 text-xs font-semibold rounded-lg whitespace-nowrap transition ${
                      selectedFileIdx === i
                        ? 'bg-indigo-600 text-white shadow-xs'
                        : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    {f.path.split('/').pop()}
                  </button>
                ))}
              </div>

              {/* Code Box */}
              <div className="p-3.5 rounded-2xl bg-slate-950 text-slate-100 font-mono text-[11px] leading-relaxed relative overflow-x-auto max-h-72 border border-slate-800">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-2">
                  <span className="text-indigo-400 font-semibold text-xs truncate max-w-xs">
                    {ANDROID_PROJECT_FILES[selectedFileIdx].path}
                  </span>
                  <button
                    onClick={() =>
                      copyCode(
                        ANDROID_PROJECT_FILES[selectedFileIdx].content,
                        ANDROID_PROJECT_FILES[selectedFileIdx].path
                      )
                    }
                    className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 flex items-center gap-1 transition shrink-0"
                  >
                    {copiedFile === ANDROID_PROJECT_FILES[selectedFileIdx].path ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-400" /> Copied
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" /> Copy Code
                      </>
                    )}
                  </button>
                </div>
                <pre>{ANDROID_PROJECT_FILES[selectedFileIdx].content}</pre>
              </div>

              {/* Installation Guide text */}
              <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs space-y-2">
                <h5 className="font-bold text-slate-800 dark:text-slate-200">
                  Step-by-Step Installation & Build Guide:
                </h5>
                <div className="text-slate-600 dark:text-slate-400 whitespace-pre-wrap font-sans text-xs">
                  {INSTALLATION_GUIDE}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Review Schedules Section */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs space-y-4">
        <h4 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
          <Clock className="w-4 h-4 text-indigo-600" />
          Daily Review Times
        </h4>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <div>
            <label className="font-semibold text-slate-700 dark:text-slate-300">
              Morning Questions Time
            </label>
            <input
              type="time"
              value={settings.morningReviewTime}
              onChange={(e) =>
                onUpdateSettings({ ...settings, morningReviewTime: e.target.value })
              }
              className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-medium"
            />
            <span className="text-[10px] text-slate-400 mt-0.5 block">
              Default: 7:00 AM
            </span>
          </div>

          <div>
            <label className="font-semibold text-slate-700 dark:text-slate-300">
              Evening Review Time
            </label>
            <input
              type="time"
              value={settings.eveningReviewTime}
              onChange={(e) =>
                onUpdateSettings({ ...settings, eveningReviewTime: e.target.value })
              }
              className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-medium"
            />
            <span className="text-[10px] text-slate-400 mt-0.5 block">
              Default: 8:00 PM
            </span>
          </div>

          <div>
            <label className="font-semibold text-slate-700 dark:text-slate-300">
              Default Reminder Time
            </label>
            <input
              type="time"
              value={settings.defaultReminderTime}
              onChange={(e) =>
                onUpdateSettings({ ...settings, defaultReminderTime: e.target.value })
              }
              className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-medium"
            />
            <span className="text-[10px] text-slate-400 mt-0.5 block">
              For unscheduled tasks
            </span>
          </div>
        </div>
      </div>

      {/* Sound, Vibration & Snooze Duration */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs space-y-4">
        <h4 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
          <Volume2 className="w-4 h-4 text-emerald-600" />
          Alerts, Sound & Vibration
        </h4>

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                Gentle Audio Chime
              </p>
              <p className="text-[11px] text-slate-400">
                Play pleasant harmonic reminder sound
              </p>
            </div>
            <input
              type="checkbox"
              checked={settings.soundEnabled}
              onChange={(e) =>
                onUpdateSettings({ ...settings, soundEnabled: e.target.checked })
              }
              className="w-5 h-5 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer"
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                Device Vibration
              </p>
              <p className="text-[11px] text-slate-400">
                Gentle haptic vibration pattern for alarms
              </p>
            </div>
            <input
              type="checkbox"
              checked={settings.vibrationEnabled}
              onChange={(e) =>
                onUpdateSettings({ ...settings, vibrationEnabled: e.target.checked })
              }
              className="w-5 h-5 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer"
            />
          </div>

          <div className="flex items-center justify-between pt-1">
            <div>
              <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                Default Snooze Duration
              </p>
              <p className="text-[11px] text-slate-400">
                Length of reminder delay when snoozed
              </p>
            </div>
            <select
              value={settings.snoozeDurationMinutes}
              onChange={(e) =>
                onUpdateSettings({
                  ...settings,
                  snoozeDurationMinutes: parseInt(e.target.value, 10),
                })
              }
              className="px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-800 dark:text-slate-200"
            >
              <option value="5">5 minutes</option>
              <option value="10">10 minutes</option>
              <option value="15">15 minutes</option>
              <option value="30">30 minutes</option>
              <option value="60">1 hour</option>
            </select>
          </div>

          <div className="pt-2">
            <button
              onClick={handleSoundTest}
              className="w-full py-2 px-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 font-semibold text-xs border border-emerald-200 dark:border-emerald-800/60 hover:bg-emerald-100 transition flex items-center justify-center gap-1.5"
            >
              <Volume2 className="w-3.5 h-3.5" />
              Test Audio Chime & Vibration
            </button>
          </div>
        </div>
      </div>

      {/* Appearance & Personalization */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs space-y-4">
        <h4 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
          <Sun className="w-4 h-4 text-amber-500" />
          Appearance & Personalization
        </h4>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div>
            <label className="font-semibold text-slate-700 dark:text-slate-300">
              Your Preferred Name / Greeting
            </label>
            <input
              type="text"
              value={settings.userName}
              onChange={(e) => onUpdateSettings({ ...settings, userName: e.target.value })}
              className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="font-semibold text-slate-700 dark:text-slate-300">
              App Theme
            </label>
            <select
              value={settings.theme}
              onChange={(e) =>
                onUpdateSettings({ ...settings, theme: e.target.value as any })
              }
              className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
            >
              <option value="system">System Default</option>
              <option value="light">Light Theme</option>
              <option value="dark">Dark Theme</option>
            </select>
          </div>
        </div>
      </div>

      {/* Storage, Privacy & Backup */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs space-y-3">
        <h4 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
          <Database className="w-4 h-4 text-blue-600" />
          Local Storage & Offline Privacy
        </h4>
        <p className="text-xs text-slate-500 leading-relaxed">
          100% Offline-first. All your reminders, notes, and habits are stored solely on your device. No cloud upload, no tracking, and no account required.
        </p>

        {importStatus && (
          <div className="p-3 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 text-xs font-semibold">
            {importStatus}
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
          <button
            onClick={handleExportBackup}
            className="py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition"
          >
            <Download className="w-4 h-4" /> Export Backup (JSON)
          </button>

          <label className="py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer text-center">
            <Upload className="w-4 h-4" /> Restore from Backup
            <input
              type="file"
              accept=".json"
              onChange={handleImportFile}
              className="hidden"
            />
          </label>
        </div>

        <button
          onClick={handleResetData}
          className="text-xs text-rose-500 hover:text-rose-700 font-semibold pt-1 block"
        >
          Reset to default sample data
        </button>
      </div>

      {/* Android Reliability & Battery Restrictions Guide */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs space-y-3">
        <h4 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          Android Reliability & Notification Settings
        </h4>
        <div className="text-xs text-slate-600 dark:text-slate-300 space-y-2">
          <p>
            To guarantee alarms sound reliably even when the screen is locked:
          </p>
          <ul className="list-disc pl-4 space-y-1 text-slate-500 dark:text-slate-400">
            <li>
              <strong>Battery Optimization:</strong> Go to Phone Settings &gt; Apps &gt; Memory Assistant &gt; Battery &gt; Set to <em>Unrestricted</em> (or disable Battery Saver).
            </li>
            <li>
              <strong>Exact Alarms:</strong> Ensure "Schedule exact alarms" permission is allowed in Special App Access.
            </li>
            <li>
              <strong>Notifications:</strong> Ensure "Allow notifications" and "Banners / Sound" are enabled.
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};
