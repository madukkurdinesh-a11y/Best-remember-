import React, { useState } from 'react';
import { Plus, Tag, Folder, Trash2, Check, X, Sparkles } from 'lucide-react';
import { Category, Task } from '../types';
import { CategoryIcon } from './CategoryIcon';
import { AVAILABLE_ICONS, AVAILABLE_COLORS } from '../services/categories';
import { playSuccessChime } from '../services/audioNotification';

interface ScreenCategoriesProps {
  categories: Category[];
  tasks: Task[];
  onAddCategory: (category: Omit<Category, 'id' | 'isDefault'>) => void;
  onDeleteCategory: (categoryId: string) => void;
  onSelectCategoryFilter: (categoryName: string) => void;
}

export const ScreenCategories: React.FC<ScreenCategoriesProps> = ({
  categories,
  tasks,
  onAddCategory,
  onDeleteCategory,
  onSelectCategoryFilter,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [name, setName] = useState('');
  const [selectedColor, setSelectedColor] = useState(AVAILABLE_COLORS[0]);
  const [selectedIcon, setSelectedIcon] = useState(AVAILABLE_ICONS[0]);

  // Compute tasks count per category
  const countsByCategory = tasks.reduce<Record<string, number>>((acc, t) => {
    if (t.status === 'pending') {
      acc[t.category] = (acc[t.category] || 0) + 1;
    }
    return acc;
  }, {});

  const handleCreateCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    onAddCategory({
      name: name.trim(),
      color: selectedColor,
      iconName: selectedIcon,
    });

    setName('');
    setIsModalOpen(false);
    playSuccessChime();
  };

  return (
    <div className="space-y-4 pb-24">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-bold text-base text-slate-900 dark:text-white">
            Personal Life Categories
          </h3>
          <p className="text-xs text-slate-500">
            {categories.length} organized categories strictly for personal everyday life.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="p-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-indigo-600/20 active:scale-95 transition"
        >
          <Plus className="w-4 h-4" />
          <span>Add Custom</span>
        </button>
      </div>

      {/* Categories Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
        {categories.map((c) => {
          const count = countsByCategory[c.name] || 0;
          return (
            <div
              key={c.id}
              onClick={() => onSelectCategoryFilter(c.name)}
              className="p-4 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-indigo-400 transition cursor-pointer shadow-xs flex items-center justify-between group active:scale-98"
            >
              <div className="flex items-center gap-3">
                <div
                  className="w-10 h-10 rounded-2xl flex items-center justify-center text-white shadow-xs"
                  style={{ backgroundColor: c.color }}
                >
                  <CategoryIcon name={c.iconName} className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 transition">
                    {c.name}
                  </h4>
                  <span className="text-xs text-slate-400">
                    {count} pending item{count === 1 ? '' : 's'}
                  </span>
                </div>
              </div>

              {!c.isDefault && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteCategory(c.id);
                  }}
                  className="p-1.5 text-slate-400 hover:text-rose-500 rounded-lg opacity-0 group-hover:opacity-100 transition"
                  title="Delete custom category"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
          );
        })}
      </div>

      {/* Add Custom Category Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl shadow-2xl p-5 border border-slate-200 dark:border-slate-800 animate-in fade-in duration-200">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-indigo-600" />
                New Custom Category
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateCategory} className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Category Name
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Garden Care, Pet Care, Knitting..."
                  className="w-full mt-1 px-3.5 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* Color Picker */}
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1.5">
                  Choose Color
                </label>
                <div className="flex flex-wrap gap-2">
                  {AVAILABLE_COLORS.map((col) => (
                    <button
                      type="button"
                      key={col}
                      onClick={() => setSelectedColor(col)}
                      className={`w-7 h-7 rounded-full transition flex items-center justify-center ${
                        selectedColor === col ? 'ring-2 ring-offset-2 ring-indigo-500 scale-110' : ''
                      }`}
                      style={{ backgroundColor: col }}
                    >
                      {selectedColor === col && <Check className="w-4 h-4 text-white" />}
                    </button>
                  ))}
                </div>
              </div>

              {/* Icon Picker */}
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1.5">
                  Choose Icon
                </label>
                <div className="grid grid-cols-6 gap-2">
                  {AVAILABLE_ICONS.map((ico) => (
                    <button
                      type="button"
                      key={ico}
                      onClick={() => setSelectedIcon(ico)}
                      className={`p-2.5 rounded-xl border flex items-center justify-center transition ${
                        selectedIcon === ico
                          ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400'
                          : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50'
                      }`}
                    >
                      <CategoryIcon name={ico} className="w-5 h-5" />
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 py-2.5 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white shadow-md"
                >
                  Create Category
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
