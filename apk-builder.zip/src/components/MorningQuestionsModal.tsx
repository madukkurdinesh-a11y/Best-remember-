import React, { useState } from 'react';
import {
  Sun,
  Mic,
  MicOff,
  Check,
  ChevronRight,
  Sparkles,
  X,
  Plus,
  Clock,
  Trash2,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Task, Category } from '../types';
import { parseReminderInput } from '../services/naturalLanguageParser';
import { speechService } from '../services/speechRecognition';
import { playSuccessChime, triggerVibration } from '../services/audioNotification';

interface MorningQuestionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  categories: Category[];
  existingTodayTasks: Task[];
  onConfirmPlan: (newTasks: Omit<Task, 'id' | 'createdAt' | 'updatedAt'>[]) => void;
}

const MORNING_QUESTIONS = [
  {
    id: 1,
    title: 'Daily Action',
    question: 'What do you need to do today?',
    hint: 'e.g. Clean the kitchen, take morning walk, read 20 pages',
    defaultCategory: 'Daily routine',
  },
  {
    id: 2,
    title: 'Crucial Reminder',
    question: 'What important things must you not forget?',
    hint: 'e.g. Take blood pressure medicine at 8 AM, water indoor plants',
    defaultCategory: 'Health and exercise',
  },
  {
    id: 3,
    title: 'Commitments & Family',
    question: 'Do you have any appointments or family responsibilities?',
    hint: 'e.g. Dental checkup at 2 PM, pick up nephew from school',
    defaultCategory: 'Appointments',
  },
  {
    id: 4,
    title: 'Purchases & Bills',
    question: 'Do you need to buy anything or pay any bills?',
    hint: 'e.g. Buy milk and eggs, pay electricity bill',
    defaultCategory: 'Shopping',
  },
  {
    id: 5,
    title: 'Keep in Touch',
    question: 'Is there anyone you need to call or message?',
    hint: 'e.g. Call mom tonight at 7 PM, reply to brother',
    defaultCategory: 'Calls and messages',
  },
  {
    id: 6,
    title: 'Top 3 Priorities',
    question: 'What are your three most important tasks today?',
    hint: 'e.g. Finish tax filing, doctor visit, prepare dinner',
    defaultCategory: 'Personal goals',
  },
];

export const MorningQuestionsModal: React.FC<MorningQuestionsModalProps> = ({
  isOpen,
  onClose,
  categories,
  existingTodayTasks,
  onConfirmPlan,
}) => {
  const [currentStep, setCurrentStep] = useState(0); // 0 to 5 = questions, 6 = summary
  const [answerText, setAnswerText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [optionalTime, setOptionalTime] = useState('');
  const [capturedTasks, setCapturedTasks] = useState<Omit<Task, 'id' | 'createdAt' | 'updatedAt'>[]>([]);

  if (!isOpen) return null;

  const q = MORNING_QUESTIONS[currentStep];
  const isSummaryStep = currentStep >= MORNING_QUESTIONS.length;
  const todayStr = new Date().toISOString().split('T')[0];

  const handleToggleVoice = () => {
    if (isListening) {
      speechService.stopListening();
      setIsListening(false);
      return;
    }

    speechService.startListening({
      onStart: () => setIsListening(true),
      onResult: (text, isFinal) => {
        setAnswerText(text);
        if (isFinal) setIsListening(false);
      },
      onError: () => setIsListening(false),
      onEnd: () => setIsListening(false),
    });
  };

  const handleNextQuestion = (skip = false) => {
    speechService.stopListening();
    setIsListening(false);

    if (!skip && answerText.trim()) {
      // Parse answers into one or multiple tasks
      const raw = answerText.trim();
      const lines = raw.split(/(?:,|\band\b|\n)/i).map((s) => s.trim()).filter(Boolean);

      const newTasksToAdd: Omit<Task, 'id' | 'createdAt' | 'updatedAt'>[] = [];

      lines.forEach((item) => {
        const parsed = parseReminderInput(item);
        newTasksToAdd.push({
          title: parsed.title,
          description: `Captured from Morning Planning (Q: ${q.title})`,
          date: todayStr,
          time: optionalTime || parsed.time || '09:00',
          category: parsed.category !== 'Other' ? (parsed.category || q.defaultCategory) : q.defaultCategory,
          priority: currentStep === 5 ? 'high' : (parsed.priority || 'medium'),
          repeat: 'none',
          notifyBefore: 'at_time',
          status: 'pending',
        });
      });

      setCapturedTasks((prev) => [...prev, ...newTasksToAdd]);
    }

    setAnswerText('');
    setOptionalTime('');

    if (currentStep + 1 >= MORNING_QUESTIONS.length) {
      setCurrentStep(MORNING_QUESTIONS.length);
    } else {
      setCurrentStep((prev) => prev + 1);
    }
  };

  const handleRemoveCapturedTask = (index: number) => {
    setCapturedTasks((prev) => prev.filter((_, i) => i !== index));
  };

  const handleFinalConfirm = () => {
    onConfirmPlan(capturedTasks);
    playSuccessChime();
    triggerVibration([150, 50, 150]);
    confetti({
      particleCount: 80,
      spread: 60,
      origin: { y: 0.6 },
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4">
      <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-6 duration-200">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-amber-50/50 dark:bg-amber-950/20">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-2xl bg-amber-500 text-white flex items-center justify-center shadow-md shadow-amber-500/20">
              <Sun className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-base text-slate-900 dark:text-white">
                Morning Planning
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {!isSummaryStep ? `Question ${currentStep + 1} of 6` : 'Confirm Today\'s Plan'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Progress Bar */}
        {!isSummaryStep && (
          <div className="w-full bg-amber-100 dark:bg-amber-950/40 h-1.5">
            <div
              className="bg-amber-500 h-1.5 transition-all duration-300"
              style={{ width: `${((currentStep + 1) / 6) * 100}%` }}
            />
          </div>
        )}

        {/* Body */}
        <div className="p-5 overflow-y-auto no-scrollbar flex-1 space-y-4">
          {!isSummaryStep ? (
            <div className="space-y-4">
              <div className="space-y-1">
                <span className="text-[11px] font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400">
                  {q.title}
                </span>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white leading-snug">
                  {q.question}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 italic">
                  {q.hint}
                </p>
              </div>

              {/* Voice Listening Control */}
              <div className="flex items-center justify-center py-2">
                <button
                  onClick={handleToggleVoice}
                  className={`w-16 h-16 rounded-full flex items-center justify-center transition shadow-lg ${
                    isListening
                      ? 'bg-rose-500 text-white animate-voice-listening ring-4 ring-rose-500/20'
                      : 'bg-amber-500 hover:bg-amber-600 text-white active:scale-95'
                  }`}
                >
                  <Mic className="w-7 h-7" />
                </button>
              </div>
              <p className="text-center text-xs text-slate-500">
                {isListening ? 'Listening to your voice...' : 'Tap to speak your answer'}
              </p>

              {/* Text Input area */}
              <div>
                <textarea
                  rows={3}
                  value={answerText}
                  onChange={(e) => setAnswerText(e.target.value)}
                  placeholder="Type your answer here or speak above..."
                  className="w-full p-3.5 text-sm rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500 resize-none"
                />
              </div>

              {/* Optional Reminder Time */}
              {answerText.trim() && (
                <div className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                  <Clock className="w-4 h-4 text-slate-400 shrink-0" />
                  <span className="text-xs text-slate-600 dark:text-slate-300">Set specific time (optional):</span>
                  <input
                    type="time"
                    value={optionalTime}
                    onChange={(e) => setOptionalTime(e.target.value)}
                    className="ml-auto text-xs px-2 py-1 rounded bg-white dark:bg-slate-700 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-600 focus:outline-none"
                  />
                </div>
              )}
            </div>
          ) : (
            /* Summary Step */
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 flex items-start gap-3">
                <Sparkles className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-bold text-amber-900 dark:text-amber-200">
                    Here is your plan for today!
                  </h4>
                  <p className="text-xs text-amber-700 dark:text-amber-400 mt-0.5">
                    We captured {capturedTasks.length} new items and have {existingTodayTasks.length} existing items scheduled.
                  </p>
                </div>
              </div>

              {/* Newly Captured Tasks */}
              {capturedTasks.length > 0 && (
                <div className="space-y-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    New Tasks Added This Morning ({capturedTasks.length})
                  </span>
                  <div className="space-y-2">
                    {capturedTasks.map((t, idx) => (
                      <div
                        key={idx}
                        className="p-3 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-2 shadow-xs"
                      >
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                            {t.title}
                          </p>
                          <div className="flex items-center gap-2 mt-1 text-xs text-slate-500">
                            <span>{t.time}</span>
                            <span>•</span>
                            <span className="text-indigo-600 dark:text-indigo-400">{t.category}</span>
                            {t.priority === 'high' && (
                              <span className="bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300 px-1.5 py-0.2 rounded-md font-semibold text-[10px]">
                                High
                              </span>
                            )}
                          </div>
                        </div>
                        <button
                          onClick={() => handleRemoveCapturedTask(idx)}
                          className="p-1.5 text-slate-400 hover:text-rose-500 rounded-lg"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Existing Tasks for Today */}
              {existingTodayTasks.length > 0 && (
                <div className="space-y-2 pt-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    Already on your agenda today ({existingTodayTasks.length})
                  </span>
                  <div className="space-y-2">
                    {existingTodayTasks.map((t) => (
                      <div
                        key={t.id}
                        className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 flex items-center justify-between text-xs"
                      >
                        <span className="font-medium text-slate-700 dark:text-slate-300 truncate">
                          {t.title}
                        </span>
                        <span className="text-slate-400 shrink-0 ml-2">{t.time || 'All day'}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/80 flex items-center justify-between gap-3">
          {!isSummaryStep ? (
            <>
              <button
                onClick={() => handleNextQuestion(true)}
                className="px-4 py-2.5 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200"
              >
                Skip Question
              </button>
              <button
                onClick={() => handleNextQuestion(false)}
                disabled={!answerText.trim()}
                className="flex-1 py-2.5 px-4 rounded-xl bg-amber-500 text-white font-semibold text-sm shadow-md hover:bg-amber-600 transition disabled:opacity-40 disabled:pointer-events-none flex items-center justify-center gap-1.5"
              >
                <span>Save & Continue</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </>
          ) : (
            <button
              onClick={handleFinalConfirm}
              className="w-full py-3 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm shadow-md transition active:scale-98 flex items-center justify-center gap-2"
            >
              <Check className="w-5 h-5" />
              Confirm Today's Plan
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
