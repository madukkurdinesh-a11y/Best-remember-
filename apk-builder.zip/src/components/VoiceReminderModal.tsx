import React, { useState, useEffect } from 'react';
import {
  Mic,
  MicOff,
  Sparkles,
  Check,
  Calendar,
  Clock,
  Tag,
  AlertCircle,
  HelpCircle,
  RotateCw,
  X,
  Send,
  Flag,
} from 'lucide-react';
import { Task, Category, Priority, RepeatFrequency } from '../types';
import { parseReminderInput } from '../services/naturalLanguageParser';
import { speechService } from '../services/speechRecognition';
import { playSuccessChime, triggerVibration } from '../services/audioNotification';

interface VoiceReminderModalProps {
  isOpen: boolean;
  onClose: () => void;
  categories: Category[];
  onSaveTask: (task: Omit<Task, 'id' | 'createdAt' | 'updatedAt'>) => void;
}

export const VoiceReminderModal: React.FC<VoiceReminderModalProps> = ({
  isOpen,
  onClose,
  categories,
  onSaveTask,
}) => {
  const [inputText, setInputText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [speechError, setSpeechError] = useState<string | null>(null);

  // Flow states: 'input' -> 'followup' (if needed) -> 'confirm'
  const [step, setStep] = useState<'input' | 'followup' | 'confirm'>('input');
  const [followUpQuestion, setFollowUpQuestion] = useState('');
  const [followUpAnswer, setFollowUpAnswer] = useState('');

  // Editable task details in confirmation
  const [title, setTitle] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [category, setCategory] = useState('Daily routine');
  const [priority, setPriority] = useState<Priority>('medium');
  const [repeat, setRepeat] = useState<RepeatFrequency>('none');
  const [repeatDayOfMonth, setRepeatDayOfMonth] = useState<number | undefined>(undefined);

  useEffect(() => {
    if (!isOpen) {
      // Reset state when closed
      setInputText('');
      setIsListening(false);
      setSpeechError(null);
      setStep('input');
      speechService.stopListening();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleToggleVoice = () => {
    if (isListening) {
      speechService.stopListening();
      setIsListening(false);
      return;
    }

    setSpeechError(null);
    const started = speechService.startListening({
      onStart: () => setIsListening(true),
      onResult: (transcript, isFinal) => {
        setInputText(transcript);
        if (isFinal) {
          setIsListening(false);
        }
      },
      onError: (err) => {
        setSpeechError(err);
        setIsListening(false);
      },
      onEnd: () => setIsListening(false),
    });

    if (!started && !speechService.isSupported()) {
      setSpeechError('Speech recognition is not supported in this browser. Please type your reminder below.');
    }
  };

  const handleProcessInput = (raw: string) => {
    if (!raw.trim()) return;

    const parsed = parseReminderInput(raw);
    setTitle(parsed.title);
    setDate(parsed.date || new Date().toISOString().split('T')[0]);
    setTime(parsed.time || '09:00');
    setCategory(parsed.category || 'Daily routine');
    setPriority(parsed.priority || 'medium');
    setRepeat(parsed.repeat || 'none');
    setRepeatDayOfMonth(parsed.repeatDayOfMonth);

    if (parsed.needsFollowUp && parsed.followUpQuestion) {
      setFollowUpQuestion(parsed.followUpQuestion);
      setFollowUpAnswer('');
      setStep('followup');
    } else {
      setStep('confirm');
    }
  };

  const handleFollowUpAnswer = (customAnswer?: string) => {
    const ans = customAnswer || followUpAnswer;
    if (!ans.trim()) return;

    // Combine original input and follow up answer to re-parse
    const combined = `${inputText}. ${ans}`;
    const parsed = parseReminderInput(combined);

    setTitle(parsed.title || title);
    if (parsed.date) setDate(parsed.date);
    if (parsed.time) setTime(parsed.time);
    if (parsed.category) setCategory(parsed.category);
    if (parsed.priority) setPriority(parsed.priority);
    if (parsed.repeat) setRepeat(parsed.repeat);
    if (parsed.repeatDayOfMonth) setRepeatDayOfMonth(parsed.repeatDayOfMonth);

    setStep('confirm');
  };

  const handleConfirmSchedule = () => {
    if (!title.trim()) return;

    onSaveTask({
      title: title.trim(),
      date: date || new Date().toISOString().split('T')[0],
      time: time || '09:00',
      category: category || 'Daily routine',
      priority,
      repeat,
      repeatDayOfMonth,
      notifyBefore: 'at_time',
      status: 'pending',
    });

    playSuccessChime();
    triggerVibration([100, 50, 100]);
    onClose();
  };

  const sampleChips = [
    'Remind me tomorrow at 8 AM to buy groceries.',
    'Pay the electricity bill on the 25th of every month.',
    'Call my family tonight at 7 PM.',
    'Exercise every morning at 6 AM.',
    'Remind me about doctor appointment tomorrow at 2 PM.',
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4">
      <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-6 duration-200">
        {/* Modal Header */}
        <div className="px-5 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-indigo-100 dark:bg-indigo-950 flex items-center justify-center text-indigo-600 dark:text-indigo-400">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-bold text-base text-slate-900 dark:text-white">
                {step === 'input' && 'Voice & Text Reminder'}
                {step === 'followup' && 'Just one quick question...'}
                {step === 'confirm' && 'Confirm Your Reminder'}
              </h2>
              <p className="text-xs text-slate-500">
                {step === 'input' && 'Speak naturally or type what you need to remember'}
                {step === 'followup' && 'Clarifying your reminder details'}
                {step === 'confirm' && 'Review details before scheduling'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto no-scrollbar flex-1 space-y-4">
          {step === 'input' && (
            <div className="space-y-5 text-center">
              {/* Large Microphone Action */}
              <div className="flex flex-col items-center justify-center py-2">
                <button
                  onClick={handleToggleVoice}
                  className={`w-24 h-24 rounded-full flex items-center justify-center transition-all shadow-xl active:scale-95 ${
                    isListening
                      ? 'bg-rose-500 text-white animate-voice-listening ring-8 ring-rose-500/20'
                      : 'bg-gradient-to-tr from-indigo-600 to-violet-600 text-white hover:scale-105 shadow-indigo-500/30'
                  }`}
                >
                  {isListening ? <Mic className="w-10 h-10 animate-pulse" /> : <Mic className="w-10 h-10" />}
                </button>
                <p className="mt-3 text-xs font-semibold text-slate-600 dark:text-slate-300">
                  {isListening ? 'Listening... Speak clearly now' : 'Tap microphone to speak'}
                </p>
                {speechError && (
                  <p className="mt-1 text-xs text-rose-500 max-w-xs">{speechError}</p>
                )}
              </div>

              {/* Text Input Option */}
              <div className="relative">
                <textarea
                  rows={3}
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  placeholder="e.g. Remind me tomorrow at 8 AM to buy groceries..."
                  className="w-full p-3.5 pr-12 text-sm rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition resize-none"
                />
                <button
                  disabled={!inputText.trim()}
                  onClick={() => handleProcessInput(inputText)}
                  className="absolute right-3 bottom-3 p-2 rounded-xl bg-indigo-600 text-white disabled:opacity-30 disabled:pointer-events-none hover:bg-indigo-700 transition"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>

              {/* Preset Quick Chips */}
              <div className="text-left">
                <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">
                  Try speaking or tapping:
                </span>
                <div className="flex flex-wrap gap-1.5 mt-2">
                  {sampleChips.map((chip, idx) => (
                    <button
                      key={idx}
                      onClick={() => {
                        setInputText(chip);
                        handleProcessInput(chip);
                      }}
                      className="text-xs text-left px-3 py-1.5 rounded-full bg-slate-100 hover:bg-indigo-50 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 hover:text-indigo-600 transition border border-transparent hover:border-indigo-200"
                    >
                      "{chip}"
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {step === 'followup' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 flex items-start gap-3">
                <HelpCircle className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-semibold text-amber-900 dark:text-amber-200">
                    {followUpQuestion}
                  </h4>
                  <p className="text-xs text-amber-700 dark:text-amber-400 mt-1">
                    Task: "{title}"
                  </p>
                </div>
              </div>

              {/* Quick suggestions based on question */}
              {followUpQuestion.toLowerCase().includes('time') && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {['08:00 AM', '12:00 PM', '06:00 PM', '08:00 PM'].map((t) => (
                    <button
                      key={t}
                      onClick={() => handleFollowUpAnswer(`at ${t}`)}
                      className="py-2.5 px-3 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-indigo-600 hover:text-white transition"
                    >
                      {t}
                    </button>
                  ))}
                </div>
              )}

              {followUpQuestion.toLowerCase().includes('date') && (
                <div className="grid grid-cols-3 gap-2">
                  {['Today', 'Tomorrow', 'Next week'].map((d) => (
                    <button
                      key={d}
                      onClick={() => handleFollowUpAnswer(d)}
                      className="py-2.5 px-3 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-indigo-600 hover:text-white transition"
                    >
                      {d}
                    </button>
                  ))}
                </div>
              )}

              <div className="flex gap-2">
                <input
                  type="text"
                  value={followUpAnswer}
                  onChange={(e) => setFollowUpAnswer(e.target.value)}
                  placeholder="Or type your answer here..."
                  className="flex-1 px-3.5 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleFollowUpAnswer();
                  }}
                />
                <button
                  onClick={() => handleFollowUpAnswer()}
                  className="px-4 py-2.5 bg-indigo-600 text-white rounded-xl text-sm font-medium hover:bg-indigo-700 transition"
                >
                  Confirm
                </button>
              </div>

              <button
                onClick={() => setStep('confirm')}
                className="w-full text-center text-xs text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 py-1"
              >
                Skip question and review reminder details manually
              </button>
            </div>
          )}

          {step === 'confirm' && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 flex items-center gap-2.5">
                <Check className="w-5 h-5 text-emerald-600 shrink-0" />
                <p className="text-xs font-medium text-emerald-900 dark:text-emerald-200">
                  Reminder details parsed! Please review or make any adjustments below:
                </p>
              </div>

              {/* Title Input */}
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Task Name
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full mt-1 px-3.5 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* Date & Time Row */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5" /> Date
                  </label>
                  <input
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full mt-1 px-3 py-2 text-xs sm:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" /> Time
                  </label>
                  <input
                    type="time"
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                    className="w-full mt-1 px-3 py-2 text-xs sm:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>
              </div>

              {/* Category & Priority Row */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                    <Tag className="w-3.5 h-3.5" /> Category
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full mt-1 px-3 py-2 text-xs sm:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.name}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                    <Flag className="w-3.5 h-3.5" /> Priority
                  </label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as Priority)}
                    className="w-full mt-1 px-3 py-2 text-xs sm:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none"
                  >
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High (Important)</option>
                  </select>
                </div>
              </div>

              {/* Repeat Frequency */}
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <RotateCw className="w-3.5 h-3.5" /> Repeat Frequency
                </label>
                <select
                  value={repeat}
                  onChange={(e) => setRepeat(e.target.value as RepeatFrequency)}
                  className="w-full mt-1 px-3 py-2 text-xs sm:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none"
                >
                  <option value="none">Does not repeat</option>
                  <option value="daily">Every day (Daily)</option>
                  <option value="weekly">Every week (Weekly)</option>
                  <option value="monthly">
                    {repeatDayOfMonth ? `Every month on the ${repeatDayOfMonth}th` : 'Every month (Monthly)'}
                  </option>
                  <option value="yearly">Every year (Yearly)</option>
                </select>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/80 flex items-center justify-between gap-3">
          {step === 'confirm' ? (
            <>
              <button
                onClick={() => setStep('input')}
                className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800 transition"
              >
                Back to Voice
              </button>
              <button
                onClick={handleConfirmSchedule}
                className="flex-1 py-2.5 px-4 rounded-xl bg-indigo-600 text-white font-semibold text-sm shadow-md hover:bg-indigo-700 transition active:scale-98 flex items-center justify-center gap-2"
              >
                <Check className="w-4 h-4" />
                Schedule Reminder
              </button>
            </>
          ) : (
            <button
              onClick={() => {
                if (inputText.trim()) {
                  handleProcessInput(inputText);
                } else {
                  onClose();
                }
              }}
              className="w-full py-2.5 rounded-xl bg-indigo-600 text-white font-semibold text-sm hover:bg-indigo-700 transition disabled:opacity-50"
            >
              {inputText.trim() ? 'Next' : 'Cancel'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
