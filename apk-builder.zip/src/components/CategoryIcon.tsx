import React from 'react';
import {
  Sun,
  Heart,
  ShoppingCart,
  Receipt,
  Calendar,
  Activity,
  Cake,
  PhoneCall,
  Compass,
  BookOpen,
  Home,
  Target,
  Folder,
  Coffee,
  Music,
  Smile,
  Sparkles,
  Bell,
  CheckCircle,
  LucideProps,
} from 'lucide-react';

interface CategoryIconProps extends LucideProps {
  name: string;
}

export const CategoryIcon: React.FC<CategoryIconProps> = ({ name, ...props }) => {
  switch (name) {
    case 'Sun':
      return <Sun {...props} />;
    case 'Heart':
      return <Heart {...props} />;
    case 'ShoppingCart':
      return <ShoppingCart {...props} />;
    case 'Receipt':
      return <Receipt {...props} />;
    case 'Calendar':
      return <Calendar {...props} />;
    case 'Activity':
      return <Activity {...props} />;
    case 'Cake':
      return <Cake {...props} />;
    case 'PhoneCall':
      return <PhoneCall {...props} />;
    case 'Compass':
      return <Compass {...props} />;
    case 'BookOpen':
      return <BookOpen {...props} />;
    case 'Home':
      return <Home {...props} />;
    case 'Target':
      return <Target {...props} />;
    case 'Coffee':
      return <Coffee {...props} />;
    case 'Music':
      return <Music {...props} />;
    case 'Smile':
      return <Smile {...props} />;
    case 'Sparkles':
      return <Sparkles {...props} />;
    case 'Bell':
      return <Bell {...props} />;
    case 'CheckCircle':
      return <CheckCircle {...props} />;
    case 'Folder':
    default:
      return <Folder {...props} />;
  }
};
