import React, { useState } from 'react';
import {
  Moon,
  CheckCircle2,
  Circle,
  ArrowRight,
  Sparkles,
  X,
  Calendar,
  AlertCircle,
  Plus,
  Mic,
  RotateCcw,
  Check,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Task } from '../types';
import { parseReminderInput } from '../services/naturalLanguageParser';
import { speechService } from '../services/speechRecognition';
import { playSuccessChime, triggerVibration } from '../services/audioNotification';

interface EveningReviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  todayTasks: Task[];
  upcomingTasks: Task[];
  onCompleteTask: (taskId: string) => void;
  onPostponeTask: (taskId: string, minutes?: number) => void;
  onAddNewTask: (task: Omit<Task, 'id' | 'createdAt' | 'updatedAt'>) => void;
}

export const EveningReviewModal: React.FC<EveningReviewModalProps> = ({
  isOpen,
  onClose,
  todayTasks,
  upcomingTasks,
  onCompleteTask,
  onPostponeTask,
  onAddNewTask,
}) => {
  const [step, setStep] = useState(1); // 1 to 5, then 6 is Summary
  const [forgottenText, setForgottenText] = useState('');
  const [isListening, setIsListening] = useState(false);

  if (!isOpen) return null;

  const completedToday = todayTasks.filter((t) => t.status === 'completed');
  const pendingToday = todayTasks.filter((t) => t.status === 'pending');

  const tomorrowStr = (() => {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    return d.toISOString().split('T')[0];
  })();

  const handleToggleVoice = () => {
    if (isListening) {
      speechService.stopListening();
      setIsListening(false);
      return;
    }

    speechService.startListening({
      onStart: () => setIsListening(true),
      onResult: (text, isFinal) => {
        setForgottenText(text);
        if (isFinal) setIsListening(false);
      },
      onError: () => setIsListening(false),
      onEnd: () => setIsListening(false),
    });
  };

  const handleAddForgottenTask = () => {
    if (!forgottenText.trim()) return;
    const parsed = parseReminderInput(forgottenText);
    onAddNewTask({
      title: parsed.title,
      description: 'Captured during Evening Review',
      date: parsed.date || tomorrowStr,
      time: parsed.time || '09:00',
      category: parsed.category || 'Daily routine',
      priority: parsed.priority || 'medium',
      repeat: 'none',
      notifyBefore: 'at_time',
      status: 'pending',
    });
    setForgottenText('');
    playSuccessChime();
  };

  const handleMoveAllPendingToTomorrow = () => {
    pendingToday.forEach((t) => {
      onPostponeTask(t.id, 1440); // 1440 mins = 1 day
    });
    playSuccessChime();
    triggerVibration([100, 50, 100]);
  };

  const handleFinishReview = () => {
    playSuccessChime();
    triggerVibration([150, 100, 200]);
    confetti({
      particleCount: 90,
      spread: 70,
      origin: { y: 0.6 },
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4">
      <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-6 duration-200">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-indigo-50/60 dark:bg-indigo-950/30">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-2xl bg-indigo-600 text-white flex items-center justify-center shadow-md shadow-indigo-600/20">
              <Moon className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-base text-slate-900 dark:text-white">
                Evening Review & Wind-down
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {step <= 5 ? `Step ${step} of 5` : 'Tomorrow Prepared'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Progress Bar */}
        {step <= 5 && (
          <div className="w-full bg-indigo-100 dark:bg-indigo-950/40 h-1.5">
            <div
              className="bg-indigo-600 h-1.5 transition-all duration-300"
              style={{ width: `${(step / 5) * 100}%` }}
            />
          </div>
        )}

        {/* Body */}
        <div className="p-5 overflow-y-auto no-scrollbar flex-1 space-y-4">
          {/* Step 1: Which tasks did you complete today? */}
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                  Step 1: Celebrate Progress
                </span>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white leading-snug">
                  Which tasks did you complete today?
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Tap to mark any finished tasks. You finished {completedToday.length} task{completedToday.length === 1 ? '' : 's'} so far!
                </p>
              </div>

              {todayTasks.length === 0 ? (
                <div className="text-center py-6 text-sm text-slate-500">
                  No tasks were scheduled for today.
                </div>
              ) : (
                <div className="space-y-2">
                  {todayTasks.map((t) => {
                    const isDone = t.status === 'completed';
                    return (
                      <button
                        key={t.id}
                        onClick={() => onCompleteTask(t.id)}
                        className={`w-full p-3.5 rounded-2xl border text-left flex items-center gap-3 transition ${
                          isDone
                            ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-slate-800 dark:text-slate-200'
                            : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-indigo-300'
                        }`}
                      >
                        {isDone ? (
                          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                        ) : (
                          <Circle className="w-5 h-5 text-slate-400 shrink-0" />
                        )}
                        <div className="flex-1 min-w-0">
                          <p
                            className={`text-sm font-semibold truncate ${
                              isDone ? 'line-through text-slate-500 dark:text-slate-400' : 'text-slate-900 dark:text-white'
                            }`}
                          >
                            {t.title}
                          </p>
                          <span className="text-xs text-slate-400">
                            {t.category} • {t.time || 'All day'}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* Step 2: Which tasks are still pending? */}
          {step === 2 && (
            <div className="space-y-4">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                  Step 2: Review Incomplete Items
                </span>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white leading-snug">
                  Which tasks are still pending?
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {pendingToday.length > 0
                    ? `You have ${pendingToday.length} pending task${pendingToday.length === 1 ? '' : 's'}. Choose what to do:`
                    : 'Great job! You have zero pending tasks for today.'}
                </p>
              </div>

              {pendingToday.length === 0 ? (
                <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 text-emerald-800 dark:text-emerald-300 text-center text-sm font-medium">
                  🎉 Everything planned for today has been accomplished!
                </div>
              ) : (
                <div className="space-y-2.5">
                  {pendingToday.map((t) => (
                    <div
                      key={t.id}
                      className="p-3.5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs"
                    >
                      <p className="text-sm font-semibold text-slate-900 dark:text-white">
                        {t.title}
                      </p>
                      <div className="flex items-center gap-2 mt-2">
                        <button
                          onClick={() => onCompleteTask(t.id)}
                          className="px-2.5 py-1.5 rounded-lg bg-emerald-100 hover:bg-emerald-200 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 text-xs font-semibold flex items-center gap-1 transition"
                        >
                          <Check className="w-3.5 h-3.5" /> Done
                        </button>
                        <button
                          onClick={() => onPostponeTask(t.id, 1440)}
                          className="px-2.5 py-1.5 rounded-lg bg-indigo-100 hover:bg-indigo-200 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300 text-xs font-semibold flex items-center gap-1 transition"
                        >
                          <ArrowRight className="w-3.5 h-3.5" /> Move to Tomorrow
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Step 3: Did you forget anything important? */}
          {step === 3 && (
            <div className="space-y-4">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                  Step 3: Clear Your Mind
                </span>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white leading-snug">
                  Did you forget anything important today?
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Say it aloud or write it down so your mind can rest easy tonight.
                </p>
              </div>

              {/* Voice button */}
              <div className="flex items-center justify-center py-2">
                <button
                  onClick={handleToggleVoice}
                  className={`w-16 h-16 rounded-full flex items-center justify-center transition shadow-lg ${
                    isListening
                      ? 'bg-rose-500 text-white animate-voice-listening ring-4 ring-rose-500/20'
                      : 'bg-indigo-600 hover:bg-indigo-700 text-white active:scale-95'
                  }`}
                >
                  <Mic className="w-7 h-7" />
                </button>
              </div>
              <p className="text-center text-xs text-slate-500">
                {isListening ? 'Listening...' : 'Tap to speak anything on your mind'}
              </p>

              <div className="flex gap-2">
                <input
                  type="text"
                  value={forgottenText}
                  onChange={(e) => setForgottenText(e.target.value)}
                  placeholder="e.g. Call dentist tomorrow morning, buy bread..."
                  className="flex-1 px-3.5 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleAddForgottenTask();
                  }}
                />
                <button
                  onClick={handleAddForgottenTask}
                  disabled={!forgottenText.trim()}
                  className="px-4 py-2.5 bg-indigo-600 text-white rounded-xl text-sm font-semibold hover:bg-indigo-700 disabled:opacity-40 transition"
                >
                  Save
                </button>
              </div>
            </div>
          )}

          {/* Step 4: What should be moved to tomorrow? */}
          {step === 4 && (
            <div className="space-y-4">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                  Step 4: Tomorrow's Handover
                </span>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white leading-snug">
                  What should be moved to tomorrow?
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Move remaining items forward so no tasks are lost.
                </p>
              </div>

              {pendingToday.length > 0 ? (
                <div className="space-y-3">
                  <button
                    onClick={handleMoveAllPendingToTomorrow}
                    className="w-full p-3.5 rounded-2xl bg-indigo-50 dark:bg-indigo-950/50 border border-indigo-200 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300 font-bold text-sm flex items-center justify-center gap-2 hover:bg-indigo-100 transition"
                  >
                    <RotateCcw className="w-4 h-4" />
                    Move All {pendingToday.length} Pending Tasks to Tomorrow
                  </button>

                  <div className="space-y-2">
                    {pendingToday.map((t) => (
                      <div
                        key={t.id}
                        className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-between text-xs"
                      >
                        <span className="font-semibold text-slate-800 dark:text-slate-200 truncate">
                          {t.title}
                        </span>
                        <button
                          onClick={() => onPostponeTask(t.id, 1440)}
                          className="px-2.5 py-1 text-xs rounded-lg bg-indigo-600 text-white hover:bg-indigo-700"
                        >
                          Move
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 text-emerald-800 dark:text-emerald-300 text-center text-sm font-medium">
                  All pending tasks have already been handled for tomorrow!
                </div>
              )}
            </div>
          )}

          {/* Step 5: Upcoming appointments, birthdays, or bills to prepare for */}
          {step === 5 && (
            <div className="space-y-4">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                  Step 5: Look Ahead
                </span>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white leading-snug">
                  Upcoming appointments, birthdays, or bills
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Here is what is coming up over the next few days:
                </p>
              </div>

              {upcomingTasks.length === 0 ? (
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800 text-slate-500 text-center text-sm">
                  No upcoming appointments or bills scheduled for the next 7 days.
                </div>
              ) : (
                <div className="space-y-2">
                  {upcomingTasks.slice(0, 5).map((t) => (
                    <div
                      key={t.id}
                      className="p-3 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-between text-xs shadow-xs"
                    >
                      <div>
                        <p className="font-semibold text-slate-900 dark:text-white">
                          {t.title}
                        </p>
                        <span className="text-slate-500">
                          {t.category} • {t.date} at {t.time || 'All day'}
                        </span>
                      </div>
                      <span className="px-2 py-0.5 rounded-full bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 font-semibold">
                        Upcoming
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Step 6: Simple Summary */}
          {step === 6 && (
            <div className="space-y-4 text-center py-2">
              <div className="w-14 h-14 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-600 flex items-center justify-center mx-auto shadow-md">
                <Sparkles className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                Evening Review Complete!
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xs mx-auto">
                Tomorrow's schedule is prepared and safe. You can sleep peacefully knowing your memory assistant has everything recorded.
              </p>
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-left text-xs space-y-1.5">
                <p className="font-semibold text-slate-800 dark:text-slate-200">
                  Today's Summary:
                </p>
                <p className="text-emerald-600 font-medium">✓ Completed: {completedToday.length} task{completedToday.length === 1 ? '' : 's'}</p>
                <p className="text-indigo-600 font-medium">→ Ready for tomorrow: {upcomingTasks.length + pendingToday.length} item(s)</p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/80 flex items-center justify-between gap-3">
          {step < 5 ? (
            <>
              <button
                onClick={() => setStep((prev) => Math.max(1, prev - 1))}
                disabled={step === 1}
                className="px-3.5 py-2 text-xs font-semibold text-slate-500 hover:text-slate-800 disabled:opacity-30"
              >
                Back
              </button>
              <button
                onClick={() => setStep((prev) => prev + 1)}
                className="flex-1 py-2.5 px-4 rounded-xl bg-indigo-600 text-white font-semibold text-sm shadow-md hover:bg-indigo-700 transition flex items-center justify-center gap-1.5"
              >
                <span>Continue</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </>
          ) : step === 5 ? (
            <button
              onClick={() => setStep(6)}
              className="w-full py-2.5 px-4 rounded-xl bg-indigo-600 text-white font-semibold text-sm shadow-md hover:bg-indigo-700 transition flex items-center justify-center gap-1.5"
            >
              <span>View Evening Summary</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={handleFinishReview}
              className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-md transition active:scale-98 flex items-center justify-center gap-2"
            >
              <Check className="w-5 h-5" />
              Good Night & Save Tomorrow's Plan
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
