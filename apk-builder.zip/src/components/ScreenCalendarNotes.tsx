import React, { useState } from 'react';
import {
  Calendar as CalendarIcon,
  StickyNote,
  ChevronLeft,
  ChevronRight,
  Plus,
  Star,
  Clock,
  ArrowRight,
  Check,
  Trash2,
  Edit3,
  Sparkles,
} from 'lucide-react';
import { Task, Note, Category } from '../types';
import { playSuccessChime } from '../services/audioNotification';

interface ScreenCalendarNotesProps {
  tasks: Task[];
  notes: Note[];
  categories: Category[];
  onSaveNote: (note: Omit<Note, 'id' | 'createdAt' | 'updatedAt'>, id?: string) => void;
  onDeleteNote: (noteId: string) => void;
  onConvertNoteToTask: (note: Note, date: string, time: string, category: string) => void;
  onOpenAddTaskForDate: (dateStr: string) => void;
}

export const ScreenCalendarNotes: React.FC<ScreenCalendarNotesProps> = ({
  tasks,
  notes,
  categories,
  onSaveNote,
  onDeleteNote,
  onConvertNoteToTask,
  onOpenAddTaskForDate,
}) => {
  const [activeTab, setActiveTab] = useState<'calendar' | 'notes'>('calendar');
  const [calendarView, setCalendarView] = useState<'month' | 'week' | 'day'>('month');

  // Calendar date state
  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [selectedDateStr, setSelectedDateStr] = useState<string>(
    new Date().toISOString().split('T')[0]
  );

  // Note editor modal
  const [editingNote, setEditingNote] = useState<Note | null>(null);
  const [isNoteModalOpen, setIsNoteModalOpen] = useState(false);
  const [noteTitle, setNoteTitle] = useState('');
  const [noteContent, setNoteContent] = useState('');
  const [noteIsImportant, setNoteIsImportant] = useState(false);

  // Convert Note to Task modal
  const [convertingNote, setConvertingNote] = useState<Note | null>(null);
  const [convertDate, setConvertDate] = useState(new Date().toISOString().split('T')[0]);
  const [convertTime, setConvertTime] = useState('09:00');
  const [convertCategory, setConvertCategory] = useState('Daily routine');

  const todayStr = new Date().toISOString().split('T')[0];

  // Month navigation helpers
  const handlePrev = () => {
    const d = new Date(currentDate);
    if (calendarView === 'month') d.setMonth(d.getMonth() - 1);
    else if (calendarView === 'week') d.setDate(d.getDate() - 7);
    else d.setDate(d.getDate() - 1);
    setCurrentDate(d);
  };

  const handleNext = () => {
    const d = new Date(currentDate);
    if (calendarView === 'month') d.setMonth(d.getMonth() + 1);
    else if (calendarView === 'week') d.setDate(d.getDate() + 7);
    else d.setDate(d.getDate() + 1);
    setCurrentDate(d);
  };

  const handleJumpToday = () => {
    const today = new Date();
    setCurrentDate(today);
    setSelectedDateStr(today.toISOString().split('T')[0]);
  };

  // Generate Month Grid Days
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const firstDayOfMonth = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const daysInPrevMonth = new Date(year, month, 0).getDate();
  const prevMonthCells: number[] = [];
  for (let i = firstDayOfMonth - 1; i >= 0; i--) {
    prevMonthCells.push(daysInPrevMonth - i);
  }

  const currentMonthDays: number[] = [];
  for (let i = 1; i <= daysInMonth; i++) {
    currentMonthDays.push(i);
  }

  // Generate tasks map for calendar dots
  const tasksByDate = tasks.reduce<Record<string, Task[]>>((acc, t) => {
    if (!acc[t.date]) acc[t.date] = [];
    acc[t.date].push(t);
    return acc;
  }, {});

  const selectedDayTasks = tasksByDate[selectedDateStr] || [];

  // Note actions
  const openNewNoteModal = () => {
    setEditingNote(null);
    setNoteTitle('');
    setNoteContent('');
    setNoteIsImportant(false);
    setIsNoteModalOpen(true);
  };

  const openEditNoteModal = (note: Note) => {
    setEditingNote(note);
    setNoteTitle(note.title);
    setNoteContent(note.content);
    setNoteIsImportant(note.isImportant);
    setIsNoteModalOpen(true);
  };

  const handleSaveNoteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteTitle.trim()) return;
    onSaveNote(
      {
        title: noteTitle.trim(),
        content: noteContent.trim(),
        isImportant: noteIsImportant,
      },
      editingNote?.id
    );
    setIsNoteModalOpen(false);
  };

  const handleConvertSubmit = () => {
    if (!convertingNote) return;
    onConvertNoteToTask(convertingNote, convertDate, convertTime, convertCategory);
    setConvertingNote(null);
    playSuccessChime();
  };

  return (
    <div className="space-y-4 pb-24">
      {/* Top Segmented Controls: Calendar vs Notes */}
      <div className="flex p-1 rounded-2xl bg-slate-200/80 dark:bg-slate-800/80 max-w-sm mx-auto">
        <button
          onClick={() => setActiveTab('calendar')}
          className={`flex-1 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
            activeTab === 'calendar'
              ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          <CalendarIcon className="w-4 h-4" />
          Calendar
        </button>
        <button
          onClick={() => setActiveTab('notes')}
          className={`flex-1 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
            activeTab === 'notes'
              ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          <StickyNote className="w-4 h-4" />
          Notes ({notes.length})
        </button>
      </div>

      {activeTab === 'calendar' ? (
        <div className="space-y-4">
          {/* Calendar Header Controls */}
          <div className="p-4 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-base text-slate-900 dark:text-white">
                  {currentDate.toLocaleDateString(undefined, {
                    month: 'long',
                    year: 'numeric',
                  })}
                </h3>
                <span className="text-xs text-slate-400">
                  Selected: {selectedDateStr}
                </span>
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={handleJumpToday}
                  className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-300 hover:bg-indigo-100"
                >
                  Today
                </button>
                <button
                  onClick={handlePrev}
                  className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={handleNext}
                  className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* View Mode Switcher: Month / Week / Day */}
            <div className="flex gap-1 border-t border-slate-100 dark:border-slate-700/60 pt-2 text-xs">
              {(['month', 'week', 'day'] as const).map((mode) => (
                <button
                  key={mode}
                  onClick={() => setCalendarView(mode)}
                  className={`px-3 py-1 rounded-lg capitalize font-semibold transition ${
                    calendarView === mode
                      ? 'bg-indigo-600 text-white'
                      : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-700'
                  }`}
                >
                  {mode} View
                </button>
              ))}
            </div>

            {/* Monthly Calendar Grid */}
            {calendarView === 'month' && (
              <div>
                {/* Day of Week Headers */}
                <div className="grid grid-cols-7 text-center text-[11px] font-bold text-slate-400 py-1 border-b border-slate-100 dark:border-slate-700/60">
                  {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d) => (
                    <span key={d}>{d}</span>
                  ))}
                </div>

                <div className="grid grid-cols-7 text-center gap-1 pt-1">
                  {/* Previous month empty days */}
                  {prevMonthCells.map((dayNum, i) => (
                    <div
                      key={`prev-${i}`}
                      className="py-2 text-xs text-slate-300 dark:text-slate-600 select-none"
                    >
                      {dayNum}
                    </div>
                  ))}

                  {/* Current Month Days */}
                  {currentMonthDays.map((dayNum) => {
                    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
                    const isSelected = dateStr === selectedDateStr;
                    const isToday = dateStr === todayStr;
                    const dayTasks = tasksByDate[dateStr] || [];
                    const hasPending = dayTasks.some((t) => t.status === 'pending');
                    const hasDone = dayTasks.some((t) => t.status === 'completed');

                    return (
                      <button
                        key={dayNum}
                        onClick={() => setSelectedDateStr(dateStr)}
                        className={`py-2 px-1 rounded-xl text-xs font-semibold relative flex flex-col items-center justify-center transition ${
                          isSelected
                            ? 'bg-indigo-600 text-white shadow-md'
                            : isToday
                            ? 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-bold'
                            : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700'
                        }`}
                      >
                        <span>{dayNum}</span>

                        {/* Task Dot Indicators */}
                        <div className="flex gap-0.5 mt-0.5 h-1">
                          {hasPending && (
                            <span
                              className={`w-1 h-1 rounded-full ${
                                isSelected ? 'bg-amber-300' : 'bg-indigo-500'
                              }`}
                            />
                          )}
                          {hasDone && (
                            <span
                              className={`w-1 h-1 rounded-full ${
                                isSelected ? 'bg-emerald-300' : 'bg-emerald-500'
                              }`}
                            />
                          )}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Weekly Calendar View */}
            {calendarView === 'week' && (
              <div className="grid grid-cols-7 gap-1 pt-2 text-center">
                {Array.from({ length: 7 }).map((_, i) => {
                  const d = new Date(currentDate);
                  const currentDay = d.getDay();
                  d.setDate(d.getDate() - currentDay + i);
                  const dateStr = d.toISOString().split('T')[0];
                  const isSelected = dateStr === selectedDateStr;
                  const isToday = dateStr === todayStr;
                  const count = (tasksByDate[dateStr] || []).length;

                  return (
                    <button
                      key={i}
                      onClick={() => setSelectedDateStr(dateStr)}
                      className={`p-2 rounded-xl text-xs flex flex-col items-center gap-1 transition ${
                        isSelected
                          ? 'bg-indigo-600 text-white font-bold'
                          : isToday
                          ? 'bg-indigo-50 dark:bg-indigo-950 text-indigo-600'
                          : 'hover:bg-slate-100 dark:hover:bg-slate-700'
                      }`}
                    >
                      <span className="text-[10px] uppercase text-slate-400">
                        {d.toLocaleDateString(undefined, { weekday: 'narrow' })}
                      </span>
                      <span className="font-bold text-sm">{d.getDate()}</span>
                      {count > 0 && (
                        <span className="text-[10px] px-1 bg-amber-400/20 text-amber-700 dark:text-amber-300 rounded-full font-bold">
                          {count}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            )}

            {/* Daily Calendar View */}
            {calendarView === 'day' && (
              <div className="py-2 text-center">
                <span className="text-sm font-bold text-slate-800 dark:text-slate-200">
                  Daily Detailed Schedule for {selectedDateStr}
                </span>
              </div>
            )}
          </div>

          {/* Schedule for Selected Date */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <Clock className="w-4 h-4 text-indigo-600" />
                Tasks on {selectedDateStr} ({selectedDayTasks.length})
              </h4>
              <button
                onClick={() => onOpenAddTaskForDate(selectedDateStr)}
                className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" /> Add for this day
              </button>
            </div>

            {selectedDayTasks.length === 0 ? (
              <div className="p-6 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-center text-xs text-slate-400">
                No reminders scheduled on this day.
              </div>
            ) : (
              <div className="space-y-2">
                {selectedDayTasks.map((task) => (
                  <div
                    key={task.id}
                    className="p-3 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-2 shadow-xs"
                  >
                    <div>
                      <p
                        className={`text-sm font-semibold ${
                          task.status === 'completed'
                            ? 'line-through text-slate-400'
                            : 'text-slate-900 dark:text-white'
                        }`}
                      >
                        {task.title}
                      </p>
                      <span className="text-xs text-slate-500">
                        {task.time || 'All day'} • {task.category}
                      </span>
                    </div>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        task.status === 'completed'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300'
                      }`}
                    >
                      {task.status}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      ) : (
        /* NOTES TAB */
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                Personal Notes & Memory Log
              </h3>
              <p className="text-xs text-slate-500">
                Capture things to remember later. You can convert any note into a reminder task.
              </p>
            </div>
            <button
              onClick={openNewNoteModal}
              className="p-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-indigo-600/20 active:scale-95 transition shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>New Note</span>
            </button>
          </div>

          {notes.length === 0 ? (
            <div className="p-8 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-center space-y-2">
              <StickyNote className="w-10 h-10 text-slate-300 mx-auto" />
              <p className="text-sm font-bold text-slate-700 dark:text-slate-300">
                Your notes area is empty
              </p>
              <p className="text-xs text-slate-400">
                Record thoughts, book recommendations, or doctor tips here.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {notes.map((note) => (
                <div
                  key={note.id}
                  className={`p-4 rounded-3xl border transition shadow-xs flex flex-col justify-between ${
                    note.isImportant
                      ? 'bg-amber-50/70 dark:bg-amber-950/20 border-amber-300 dark:border-amber-800/60 ring-1 ring-amber-300/50'
                      : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700'
                  }`}
                >
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                        {note.title}
                      </h4>
                      {note.isImportant && (
                        <Star className="w-4 h-4 text-amber-500 fill-amber-500 shrink-0" />
                      )}
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-2 whitespace-pre-wrap leading-relaxed">
                      {note.content}
                    </p>
                  </div>

                  <div className="pt-4 mt-3 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-xs">
                    {/* Convert to scheduled task button */}
                    <button
                      onClick={() => {
                        setConvertingNote(note);
                        setConvertDate(todayStr);
                        setConvertTime('09:00');
                        setConvertCategory(note.category || 'Daily routine');
                      }}
                      className="px-2.5 py-1 rounded-xl bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950 dark:hover:bg-indigo-900 text-indigo-700 dark:text-indigo-300 font-bold flex items-center gap-1 transition"
                      title="Convert this note into a scheduled task"
                    >
                      <Sparkles className="w-3 h-3" />
                      Convert to Task
                    </button>

                    <div className="flex items-center gap-1 text-slate-400">
                      <button
                        onClick={() => openEditNoteModal(note)}
                        className="p-1 hover:text-indigo-600 rounded"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => onDeleteNote(note.id)}
                        className="p-1 hover:text-rose-500 rounded"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Note Editor Modal */}
      {isNoteModalOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl shadow-2xl p-5 border border-slate-200 dark:border-slate-800 animate-in fade-in duration-200">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-3">
              {editingNote ? 'Edit Note' : 'Create Quick Note'}
            </h3>
            <form onSubmit={handleSaveNoteSubmit} className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Note Title
                </label>
                <input
                  type="text"
                  required
                  value={noteTitle}
                  onChange={(e) => setNoteTitle(e.target.value)}
                  placeholder="e.g. Doctor recommendation, Plant watering tips..."
                  className="w-full mt-1 px-3.5 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Content
                </label>
                <textarea
                  rows={4}
                  required
                  value={noteContent}
                  onChange={(e) => setNoteContent(e.target.value)}
                  placeholder="Write the details here..."
                  className="w-full mt-1 px-3.5 py-2.5 text-xs sm:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="noteImportant"
                  checked={noteIsImportant}
                  onChange={(e) => setNoteIsImportant(e.target.checked)}
                  className="rounded text-indigo-600 focus:ring-indigo-500"
                />
                <label
                  htmlFor="noteImportant"
                  className="text-xs font-medium text-slate-700 dark:text-slate-300 flex items-center gap-1 cursor-pointer"
                >
                  <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" /> Mark as Important
                </label>
              </div>

              <div className="flex gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsNoteModalOpen(false)}
                  className="flex-1 py-2.5 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white shadow-md"
                >
                  Save Note
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Convert Note into Scheduled Task Modal */}
      {convertingNote && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl shadow-2xl p-5 border border-slate-200 dark:border-slate-800 animate-in fade-in duration-200 space-y-4">
            <div className="flex items-center gap-2 text-indigo-600">
              <Sparkles className="w-5 h-5" />
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Convert Note to Scheduled Task
              </h3>
            </div>
            <p className="text-xs text-slate-500">
              Transforming note: <strong className="text-slate-800 dark:text-slate-200">"{convertingNote.title}"</strong> into a scheduled reminder.
            </p>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <label className="font-semibold text-slate-700 dark:text-slate-300">Date</label>
                <input
                  type="date"
                  value={convertDate}
                  onChange={(e) => setConvertDate(e.target.value)}
                  className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700 dark:text-slate-300">Time</label>
                <input
                  type="time"
                  value={convertTime}
                  onChange={(e) => setConvertTime(e.target.value)}
                  className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Category</label>
              <select
                value={convertCategory}
                onChange={(e) => setConvertCategory(e.target.value)}
                className="w-full mt-1 px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
              >
                {categories.map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setConvertingNote(null)}
                className="flex-1 py-2.5 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConvertSubmit}
                className="flex-1 py-2.5 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white shadow-md flex items-center justify-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                Schedule Task
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
