import React, { useState } from 'react';
import {
  Search,
  Filter,
  Plus,
  Check,
  Clock,
  Calendar,
  AlertTriangle,
  RotateCw,
  MoreVertical,
  Edit2,
  Trash2,
  CheckCircle2,
  ChevronDown,
  Tag,
} from 'lucide-react';
import { Task, Category, TaskStatus } from '../types';
import { CategoryIcon } from './CategoryIcon';

interface ScreenTasksProps {
  tasks: Task[];
  categories: Category[];
  onOpenAddTaskModal: () => void;
  onEditTask: (task: Task) => void;
  onCompleteTask: (taskId: string) => void;
  onSnoozeTask: (taskId: string, minutes: number) => void;
  onDeleteTask: (taskId: string) => void;
}

export const ScreenTasks: React.FC<ScreenTasksProps> = ({
  tasks,
  categories,
  onOpenAddTaskModal,
  onEditTask,
  onCompleteTask,
  onSnoozeTask,
  onDeleteTask,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'overdue' | 'today' | 'upcoming' | 'completed' | 'postponed'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [activeMenuTaskId, setActiveMenuTaskId] = useState<string | null>(null);

  const todayStr = new Date().toISOString().split('T')[0];

  // Filter tasks logic
  const filteredTasks = tasks.filter((t) => {
    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const match =
        t.title.toLowerCase().includes(q) ||
        (t.description && t.description.toLowerCase().includes(q)) ||
        (t.notes && t.notes.toLowerCase().includes(q));
      if (!match) return false;
    }

    // Category filter
    if (selectedCategory !== 'all' && t.category !== selectedCategory) {
      return false;
    }

    // Status filter
    if (statusFilter === 'pending') {
      return t.status === 'pending';
    }
    if (statusFilter === 'overdue') {
      return t.date < todayStr && t.status === 'pending';
    }
    if (statusFilter === 'today') {
      return t.date === todayStr;
    }
    if (statusFilter === 'upcoming') {
      return t.date > todayStr && t.status === 'pending';
    }
    if (statusFilter === 'completed') {
      return t.status === 'completed';
    }
    if (statusFilter === 'postponed') {
      return t.status === 'postponed';
    }

    return true;
  });

  const overdueCount = tasks.filter((t) => t.date < todayStr && t.status === 'pending').length;

  return (
    <div className="space-y-4 pb-24">
      {/* Search & Top Action Bar */}
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search tasks, reminders, notes..."
            className="w-full pl-9 pr-3.5 py-2.5 text-xs sm:text-sm rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-xs"
          />
        </div>
        <button
          onClick={onOpenAddTaskModal}
          className="p-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white shadow-md shadow-indigo-600/20 active:scale-95 transition flex items-center gap-1.5 shrink-0"
        >
          <Plus className="w-5 h-5" />
          <span className="text-xs font-bold hidden sm:inline">Add Task</span>
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
        {[
          { id: 'all', label: `All (${tasks.length})` },
          { id: 'pending', label: 'Pending' },
          {
            id: 'overdue',
            label: `Overdue (${overdueCount})`,
            alert: overdueCount > 0,
          },
          { id: 'today', label: 'Today' },
          { id: 'upcoming', label: 'Upcoming' },
          { id: 'completed', label: 'Completed' },
          { id: 'postponed', label: 'Postponed' },
        ].map((tab) => {
          const isActive = statusFilter === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setStatusFilter(tab.id as any)}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition ${
                tab.alert
                  ? isActive
                    ? 'bg-rose-600 text-white'
                    : 'bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 border border-rose-300'
                  : isActive
                  ? 'bg-indigo-600 text-white'
                  : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-50'
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Category Filter Chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1 text-xs">
        <button
          onClick={() => setSelectedCategory('all')}
          className={`px-2.5 py-1 rounded-lg border transition ${
            selectedCategory === 'all'
              ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 font-bold border-transparent'
              : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700'
          }`}
        >
          All Categories
        </button>
        {categories.map((c) => (
          <button
            key={c.id}
            onClick={() => setSelectedCategory(c.name)}
            className={`px-2.5 py-1 rounded-lg border whitespace-nowrap flex items-center gap-1.5 transition ${
              selectedCategory === c.name
                ? 'bg-indigo-600 text-white font-bold border-indigo-600'
                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700'
            }`}
          >
            <span
              className="w-2 h-2 rounded-full"
              style={{ backgroundColor: c.color }}
            />
            {c.name}
          </button>
        ))}
      </div>

      {/* Task List */}
      <div className="space-y-2.5">
        {filteredTasks.length === 0 ? (
          <div className="p-10 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-center space-y-2">
            <CheckCircle2 className="w-12 h-12 text-slate-300 dark:text-slate-600 mx-auto" />
            <h4 className="font-bold text-sm text-slate-700 dark:text-slate-300">
              No tasks match this filter
            </h4>
            <p className="text-xs text-slate-400">
              Try switching filters or search terms.
            </p>
          </div>
        ) : (
          filteredTasks.map((task) => {
            const isDone = task.status === 'completed';
            const isOverdue = task.date < todayStr && task.status === 'pending';
            const isToday = task.date === todayStr;

            return (
              <div
                key={task.id}
                className={`p-3.5 rounded-2xl border transition shadow-xs relative ${
                  isOverdue
                    ? 'bg-rose-50/70 dark:bg-rose-950/30 border-rose-300 dark:border-rose-900/60'
                    : isDone
                    ? 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 opacity-75'
                    : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-indigo-300'
                }`}
              >
                <div className="flex items-start gap-3">
                  {/* Completion Checkbox */}
                  <button
                    onClick={() => onCompleteTask(task.id)}
                    className={`w-6 h-6 rounded-lg border-2 mt-0.5 flex items-center justify-center transition shrink-0 ${
                      isDone
                        ? 'bg-emerald-600 border-emerald-600 text-white'
                        : 'border-slate-300 dark:border-slate-600 hover:border-indigo-600 text-transparent hover:text-indigo-600'
                    }`}
                  >
                    <Check className="w-4 h-4" />
                  </button>

                  {/* Task Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <h4
                        className={`text-sm font-bold ${
                          isDone
                            ? 'line-through text-slate-400 dark:text-slate-500'
                            : 'text-slate-900 dark:text-white'
                        }`}
                      >
                        {task.title}
                      </h4>

                      {/* Overdue Badge */}
                      {isOverdue && (
                        <span className="px-1.5 py-0.5 rounded-md text-[10px] font-bold bg-rose-500 text-white flex items-center gap-0.5 animate-pulse">
                          <AlertTriangle className="w-2.5 h-2.5" /> Overdue
                        </span>
                      )}

                      {/* Today Badge */}
                      {isToday && !isDone && (
                        <span className="px-1.5 py-0.5 rounded-md text-[10px] font-bold bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300">
                          Today
                        </span>
                      )}

                      {/* High Priority Badge */}
                      {task.priority === 'high' && (
                        <span className="px-1.5 py-0.5 rounded-md text-[10px] font-bold bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300">
                          Important
                        </span>
                      )}

                      {/* Repeat Frequency Indicator */}
                      {task.repeat !== 'none' && (
                        <span className="px-1.5 py-0.5 rounded-md text-[10px] font-semibold bg-slate-100 text-slate-600 dark:bg-slate-700 dark:text-slate-300 flex items-center gap-1">
                          <RotateCw className="w-2.5 h-2.5 text-indigo-500" />
                          {task.repeat === 'daily'
                            ? 'Daily'
                            : task.repeat === 'weekly'
                            ? 'Weekly'
                            : task.repeat === 'monthly'
                            ? `Monthly (${task.repeatDayOfMonth || 25}th)`
                            : 'Yearly'}
                        </span>
                      )}
                    </div>

                    {task.description && (
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
                        {task.description}
                      </p>
                    )}

                    {/* Metadata Row: Date, Time, Category, Notes */}
                    <div className="flex items-center gap-3 mt-2 text-xs text-slate-500 flex-wrap">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                        <span className={isOverdue ? 'text-rose-600 font-bold' : ''}>
                          {task.date}
                        </span>
                      </span>

                      {task.time && (
                        <span className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-slate-400" />
                          <span>{task.time}</span>
                        </span>
                      )}

                      <span className="flex items-center gap-1 text-indigo-600 dark:text-indigo-400 font-semibold">
                        <Tag className="w-3 h-3" />
                        <span>{task.category}</span>
                      </span>

                      {task.notes && (
                        <span className="text-[11px] text-slate-400 italic">
                          "{task.notes.slice(0, 30)}..."
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Actions Dropdown / Quick Buttons */}
                  <div className="relative shrink-0">
                    <button
                      onClick={() =>
                        setActiveMenuTaskId(activeMenuTaskId === task.id ? null : task.id)
                      }
                      className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700"
                    >
                      <MoreVertical className="w-4 h-4" />
                    </button>

                    {activeMenuTaskId === task.id && (
                      <div className="absolute right-0 top-8 z-20 w-44 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xl py-1.5 text-xs animate-in fade-in duration-150">
                        <button
                          onClick={() => {
                            onEditTask(task);
                            setActiveMenuTaskId(null);
                          }}
                          className="w-full px-3 py-2 text-left hover:bg-slate-50 dark:hover:bg-slate-700/60 flex items-center gap-2 text-slate-700 dark:text-slate-200"
                        >
                          <Edit2 className="w-3.5 h-3.5 text-indigo-500" />
                          Edit Details
                        </button>

                        <button
                          onClick={() => {
                            onSnoozeTask(task.id, 15);
                            setActiveMenuTaskId(null);
                          }}
                          className="w-full px-3 py-2 text-left hover:bg-slate-50 dark:hover:bg-slate-700/60 flex items-center gap-2 text-slate-700 dark:text-slate-200"
                        >
                          <Clock className="w-3.5 h-3.5 text-amber-500" />
                          Snooze 15 minutes
                        </button>

                        <button
                          onClick={() => {
                            onSnoozeTask(task.id, 60);
                            setActiveMenuTaskId(null);
                          }}
                          className="w-full px-3 py-2 text-left hover:bg-slate-50 dark:hover:bg-slate-700/60 flex items-center gap-2 text-slate-700 dark:text-slate-200"
                        >
                          <Clock className="w-3.5 h-3.5 text-amber-500" />
                          Snooze 1 hour
                        </button>

                        <button
                          onClick={() => {
                            onSnoozeTask(task.id, 1440); // Tomorrow
                            setActiveMenuTaskId(null);
                          }}
                          className="w-full px-3 py-2 text-left hover:bg-slate-50 dark:hover:bg-slate-700/60 flex items-center gap-2 text-slate-700 dark:text-slate-200"
                        >
                          <Calendar className="w-3.5 h-3.5 text-blue-500" />
                          Move to Tomorrow
                        </button>

                        <div className="border-t border-slate-100 dark:border-slate-700/60 my-1" />

                        <button
                          onClick={() => {
                            onDeleteTask(task.id);
                            setActiveMenuTaskId(null);
                          }}
                          className="w-full px-3 py-2 text-left hover:bg-rose-50 dark:hover:bg-rose-950/40 flex items-center gap-2 text-rose-600"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          Delete Reminder
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
