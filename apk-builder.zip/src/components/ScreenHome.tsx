import React from 'react';
import {
  Mic,
  Plus,
  StickyNote,
  Sun,
  Moon,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Calendar,
  Sparkles,
  ChevronRight,
  Star,
  Check,
  RotateCw,
} from 'lucide-react';
import { Task, Note, UserSettings } from '../types';
import { CategoryIcon } from './CategoryIcon';

interface ScreenHomeProps {
  tasks: Task[];
  notes: Note[];
  settings: UserSettings;
  onOpenVoiceModal: () => void;
  onOpenAddTaskModal: () => void;
  onOpenMorningReview: () => void;
  onOpenEveningReview: () => void;
  onNavigateToNotes: () => void;
  onNavigateToTasks: () => void;
  onCompleteTask: (taskId: string) => void;
  onSnoozeTask: (taskId: string, minutes?: number) => void;
}

export const ScreenHome: React.FC<ScreenHomeProps> = ({
  tasks,
  notes,
  settings,
  onOpenVoiceModal,
  onOpenAddTaskModal,
  onOpenMorningReview,
  onOpenEveningReview,
  onNavigateToNotes,
  onNavigateToTasks,
  onCompleteTask,
  onSnoozeTask,
}) => {
  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];

  // Greeting based on hour
  const currentHour = now.getHours();
  let greeting = 'Good morning';
  let greetingSub = 'Ready to have a clear, peaceful day?';
  if (currentHour >= 12 && currentHour < 17) {
    greeting = 'Good afternoon';
    greetingSub = 'Keep up the gentle rhythm today.';
  } else if (currentHour >= 17) {
    greeting = 'Good evening';
    greetingSub = 'Time to wind down and rest your mind.';
  }

  // Friendly date formatting: e.g. "Monday, October 19, 2026"
  const formattedDate = now.toLocaleDateString(undefined, {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
  });

  // Filter tasks
  const todayTasks = tasks.filter((t) => t.date === todayStr);
  const completedToday = todayTasks.filter((t) => t.status === 'completed');
  const pendingToday = todayTasks.filter((t) => t.status === 'pending');

  const overdueTasks = tasks.filter((t) => t.date < todayStr && t.status === 'pending');
  const importantReminders = tasks.filter(
    (t) => t.priority === 'high' && t.status === 'pending'
  );
  const upcomingAppointments = tasks.filter(
    (t) =>
      t.category === 'Appointments' &&
      t.status === 'pending' &&
      t.date >= todayStr
  );

  const totalToday = todayTasks.length;
  const progressPercent = totalToday > 0 ? Math.round((completedToday.length / totalToday) * 100) : 0;

  return (
    <div className="space-y-5 pb-24">
      {/* Greeting & Date Card */}
      <div className="p-5 rounded-3xl bg-gradient-to-br from-indigo-600 via-indigo-700 to-violet-800 text-white shadow-xl shadow-indigo-600/20 relative overflow-hidden">
        <div className="absolute -right-6 -bottom-6 w-32 h-32 rounded-full bg-white/10 blur-xl pointer-events-none" />
        <div className="relative z-10">
          <span className="text-xs font-semibold text-indigo-200 tracking-wide uppercase">
            {formattedDate}
          </span>
          <h2 className="text-2xl font-bold mt-1 text-white">
            {greeting}, {settings.userName || 'Friend'}!
          </h2>
          <p className="text-xs text-indigo-100/90 mt-1">
            {greetingSub}
          </p>

          {/* Completed vs Remaining Tracker */}
          <div className="mt-4 pt-4 border-t border-white/15">
            <div className="flex items-center justify-between text-xs font-medium">
              <span className="text-indigo-100">Today's Progress</span>
              <span className="font-bold text-white">
                {completedToday.length} of {totalToday} completed ({progressPercent}%)
              </span>
            </div>
            <div className="w-full bg-white/20 h-2.5 rounded-full mt-2 overflow-hidden">
              <div
                className="bg-emerald-400 h-2.5 rounded-full transition-all duration-500 shadow-sm"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Quick Action Buttons */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        <button
          onClick={onOpenVoiceModal}
          className="p-3.5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs hover:border-indigo-400 transition flex flex-col items-center justify-center gap-1.5 active:scale-98 group"
        >
          <div className="w-11 h-11 rounded-2xl bg-indigo-50 dark:bg-indigo-950/70 text-indigo-600 dark:text-indigo-400 flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition">
            <Mic className="w-5 h-5" />
          </div>
          <span className="text-xs font-bold text-slate-800 dark:text-slate-200 text-center">
            Voice Reminder
          </span>
        </button>

        <button
          onClick={onOpenAddTaskModal}
          className="p-3.5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs hover:border-emerald-400 transition flex flex-col items-center justify-center gap-1.5 active:scale-98 group"
        >
          <div className="w-11 h-11 rounded-2xl bg-emerald-50 dark:bg-emerald-950/70 text-emerald-600 dark:text-emerald-400 flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition">
            <Plus className="w-5 h-5" />
          </div>
          <span className="text-xs font-bold text-slate-800 dark:text-slate-200 text-center">
            Add Task
          </span>
        </button>

        <button
          onClick={onNavigateToNotes}
          className="p-3.5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs hover:border-amber-400 transition flex flex-col items-center justify-center gap-1.5 active:scale-98 group"
        >
          <div className="w-11 h-11 rounded-2xl bg-amber-50 dark:bg-amber-950/70 text-amber-600 dark:text-amber-400 flex items-center justify-center group-hover:bg-amber-600 group-hover:text-white transition">
            <StickyNote className="w-5 h-5" />
          </div>
          <span className="text-xs font-bold text-slate-800 dark:text-slate-200 text-center">
            Notes ({notes.length})
          </span>
        </button>

        <button
          onClick={currentHour < 15 ? onOpenMorningReview : onOpenEveningReview}
          className="p-3.5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs hover:border-purple-400 transition flex flex-col items-center justify-center gap-1.5 active:scale-98 group"
        >
          <div className="w-11 h-11 rounded-2xl bg-purple-50 dark:bg-purple-950/70 text-purple-600 dark:text-purple-400 flex items-center justify-center group-hover:bg-purple-600 group-hover:text-white transition">
            {currentHour < 15 ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </div>
          <span className="text-xs font-bold text-slate-800 dark:text-slate-200 text-center">
            {currentHour < 15 ? 'Morning Plan' : 'Evening Review'}
          </span>
        </button>
      </div>

      {/* OVERDUE TASKS BANNER (High Visibility) */}
      {overdueTasks.length > 0 && (
        <div className="p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-300 dark:border-rose-900/60 shadow-xs animate-in fade-in duration-200">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
              <h3 className="font-bold text-sm text-rose-900 dark:text-rose-200">
                Overdue Tasks ({overdueTasks.length})
              </h3>
            </div>
            <button
              onClick={onNavigateToTasks}
              className="text-xs font-bold text-rose-700 dark:text-rose-300 hover:underline flex items-center gap-0.5"
            >
              View all <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
          <p className="text-xs text-rose-700 dark:text-rose-300 mb-3">
            Incomplete tasks are never deleted. Tap below to reschedule to today or mark complete:
          </p>
          <div className="space-y-2">
            {overdueTasks.slice(0, 3).map((task) => (
              <div
                key={task.id}
                className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-rose-200 dark:border-rose-900/50 flex items-center justify-between gap-2"
              >
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                    {task.title}
                  </p>
                  <span className="text-[10px] text-rose-600 font-medium">
                    Due {task.date} {task.time ? `at ${task.time}` : ''}
                  </span>
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={() => onSnoozeTask(task.id, 0)} // Reschedule to today
                    className="px-2 py-1 bg-rose-100 hover:bg-rose-200 dark:bg-rose-950 text-rose-700 dark:text-rose-300 rounded-lg text-xs font-semibold transition"
                    title="Move to today's agenda"
                  >
                    Reschedule
                  </button>
                  <button
                    onClick={() => onCompleteTask(task.id)}
                    className="p-1.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-700 rounded-lg text-xs font-semibold transition"
                    title="Mark Done"
                  >
                    <Check className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TODAY'S PENDING TASKS */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-indigo-600" />
            <h3 className="font-bold text-base text-slate-900 dark:text-white">
              Today's Agenda ({pendingToday.length})
            </h3>
          </div>
          <button
            onClick={onNavigateToTasks}
            className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
          >
            Manage All
          </button>
        </div>

        {pendingToday.length === 0 ? (
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-center space-y-2">
            <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto" />
            <p className="text-sm font-bold text-slate-800 dark:text-slate-200">
              No tasks left for today!
            </p>
            <p className="text-xs text-slate-500 max-w-xs mx-auto">
              Everything scheduled for today has been finished, or you haven't added today's items yet.
            </p>
            <button
              onClick={onOpenAddTaskModal}
              className="mt-2 inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-300 text-xs font-semibold hover:bg-indigo-100"
            >
              <Plus className="w-3.5 h-3.5" /> Add New Task
            </button>
          </div>
        ) : (
          <div className="space-y-2">
            {pendingToday.map((task) => (
              <div
                key={task.id}
                className="p-3.5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-3 shadow-xs hover:border-indigo-300 transition"
              >
                <button
                  onClick={() => onCompleteTask(task.id)}
                  className="w-6 h-6 rounded-lg border-2 border-slate-300 dark:border-slate-600 hover:border-emerald-500 flex items-center justify-center text-transparent hover:text-emerald-500 transition shrink-0"
                  title="Mark Complete"
                >
                  <Check className="w-4 h-4" />
                </button>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                      {task.title}
                    </p>
                    {task.priority === 'high' && (
                      <span className="px-1.5 py-0.5 rounded-md text-[10px] font-bold bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300 shrink-0">
                        Important
                      </span>
                    )}
                    {task.repeat !== 'none' && (
                      <RotateCw className="w-3 h-3 text-indigo-500 shrink-0" />
                    )}
                  </div>
                  <div className="flex items-center gap-2 mt-1 text-xs text-slate-500">
                    <span className="font-medium text-slate-700 dark:text-slate-300">
                      {task.time || 'All day'}
                    </span>
                    <span>•</span>
                    <span className="text-indigo-600 dark:text-indigo-400 font-medium">
                      {task.category}
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => onSnoozeTask(task.id, 15)}
                  className="px-2.5 py-1 text-xs font-medium rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:text-slate-200 text-slate-600 transition shrink-0"
                >
                  Snooze
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* IMPORTANT REMINDERS & UPCOMING APPOINTMENTS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-1">
        {/* Important Reminders Card */}
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs">
          <div className="flex items-center gap-2 mb-3">
            <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
            <h4 className="font-bold text-sm text-slate-900 dark:text-white">
              Important Reminders ({importantReminders.length})
            </h4>
          </div>
          {importantReminders.length === 0 ? (
            <p className="text-xs text-slate-500 italic">No urgent high-priority items pending.</p>
          ) : (
            <div className="space-y-2">
              {importantReminders.slice(0, 3).map((item) => (
                <div key={item.id} className="text-xs border-b border-slate-100 dark:border-slate-700/60 pb-1.5 last:border-none">
                  <p className="font-semibold text-slate-800 dark:text-slate-200 truncate">
                    {item.title}
                  </p>
                  <span className="text-[11px] text-slate-400">
                    {item.date} • {item.time || 'Anytime'}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Upcoming Appointments Card */}
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs">
          <div className="flex items-center gap-2 mb-3">
            <Calendar className="w-4 h-4 text-purple-600" />
            <h4 className="font-bold text-sm text-slate-900 dark:text-white">
              Upcoming Appointments ({upcomingAppointments.length})
            </h4>
          </div>
          {upcomingAppointments.length === 0 ? (
            <p className="text-xs text-slate-500 italic">No upcoming appointments recorded.</p>
          ) : (
            <div className="space-y-2">
              {upcomingAppointments.slice(0, 3).map((item) => (
                <div key={item.id} className="text-xs border-b border-slate-100 dark:border-slate-700/60 pb-1.5 last:border-none">
                  <p className="font-semibold text-slate-800 dark:text-slate-200 truncate">
                    {item.title}
                  </p>
                  <span className="text-[11px] text-purple-600 dark:text-purple-400 font-medium">
                    {item.date} {item.time ? `at ${item.time}` : ''}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
