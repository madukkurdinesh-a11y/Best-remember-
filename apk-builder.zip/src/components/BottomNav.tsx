import React from 'react';
import { Home, CheckSquare, Calendar, StickyNote, Settings } from 'lucide-react';
import { ActiveScreen } from '../types';

interface BottomNavProps {
  activeScreen: ActiveScreen;
  onSelectScreen: (screen: ActiveScreen) => void;
  pendingCount: number;
  overdueCount: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeScreen,
  onSelectScreen,
  pendingCount,
  overdueCount,
}) => {
  const navItems = [
    { id: 'home' as ActiveScreen, label: 'Home', icon: Home },
    {
      id: 'tasks' as ActiveScreen,
      label: 'Tasks',
      icon: CheckSquare,
      badge: overdueCount > 0 ? `${overdueCount}!` : pendingCount > 0 ? `${pendingCount}` : undefined,
      badgeColor: overdueCount > 0 ? 'bg-rose-500 text-white animate-pulse' : 'bg-indigo-600 text-white',
    },
    { id: 'calendar' as ActiveScreen, label: 'Calendar', icon: Calendar },
    { id: 'notes' as ActiveScreen, label: 'Notes', icon: StickyNote },
    { id: 'settings' as ActiveScreen, label: 'Settings', icon: Settings },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 pb-safe">
      <div className="max-w-md mx-auto grid grid-cols-5 px-1 py-1.5">
        {navItems.map((item) => {
          const isActive = activeScreen === item.id;
          const Icon = item.icon;

          return (
            <button
              key={item.id}
              onClick={() => onSelectScreen(item.id)}
              className="flex flex-col items-center justify-center py-1 px-1 rounded-xl transition-all relative group"
            >
              {/* Material 3 active pill indicator */}
              <div
                className={`relative px-4 py-1 rounded-full transition-all flex items-center justify-center ${
                  isActive
                    ? 'bg-indigo-100 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400 font-semibold'
                    : 'text-slate-500 dark:text-slate-400 group-hover:text-slate-800 dark:group-hover:text-slate-200'
                }`}
              >
                <Icon className={`w-5 h-5 transition-transform ${isActive ? 'scale-110' : ''}`} />

                {item.badge && (
                  <span
                    className={`absolute -top-1 -right-1 min-w-[18px] h-[18px] text-[10px] font-bold rounded-full flex items-center justify-center px-1 shadow-xs ${item.badgeColor}`}
                  >
                    {item.badge}
                  </span>
                )}
              </div>

              <span
                className={`text-[11px] mt-0.5 tracking-tight ${
                  isActive
                    ? 'font-bold text-indigo-700 dark:text-indigo-300'
                    : 'text-slate-500 dark:text-slate-400'
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
