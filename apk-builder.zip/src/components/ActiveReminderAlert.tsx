import React from 'react';
import { Bell, Check, Clock, X, RotateCw } from 'lucide-react';
import { Task } from '../types';

interface ActiveReminderAlertProps {
  task: Task | null;
  snoozeMinutes: number;
  onComplete: (taskId: string) => void;
  onSnooze: (taskId: string, minutes: number) => void;
  onDismiss: () => void;
}

export const ActiveReminderAlert: React.FC<ActiveReminderAlertProps> = ({
  task,
  snoozeMinutes,
  onComplete,
  onSnooze,
  onDismiss,
}) => {
  if (!task) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-sm rounded-3xl bg-white dark:bg-slate-900 border-2 border-indigo-500 shadow-2xl p-5 text-center space-y-4 animate-in zoom-in-95 duration-200">
        {/* Animated Bell Badge */}
        <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-indigo-600 to-violet-600 text-white flex items-center justify-center mx-auto shadow-lg shadow-indigo-500/30 animate-bounce">
          <Bell className="w-8 h-8" />
        </div>

        <div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
            Reminder Alert
          </span>
          <h3 className="text-lg font-bold text-slate-900 dark:text-white mt-1 leading-snug">
            {task.title}
          </h3>
          {task.description && (
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              {task.description}
            </p>
          )}
          <div className="inline-flex items-center gap-1.5 mt-2 px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-xs text-slate-600 dark:text-slate-300">
            <span>{task.category}</span>
            <span>•</span>
            <span className="font-semibold">{task.time}</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2 pt-2">
          <button
            onClick={() => onComplete(task.id)}
            className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-md transition flex items-center justify-center gap-2 active:scale-98"
          >
            <Check className="w-4 h-4" />
            Mark as Done
          </button>

          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => onSnooze(task.id, snoozeMinutes)}
              className="py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition"
            >
              <Clock className="w-3.5 h-3.5 text-amber-500" />
              Snooze ({snoozeMinutes}m)
            </button>

            <button
              onClick={() => onSnooze(task.id, 1440)}
              className="py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition"
            >
              Tomorrow
            </button>
          </div>

          <button
            onClick={onDismiss}
            className="w-full text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 py-1"
          >
            Dismiss
          </button>
        </div>
      </div>
    </div>
  );
};
