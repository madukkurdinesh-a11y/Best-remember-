import React, { useState, useEffect } from 'react';
import { Bell, BellOff, Download, Sparkles, WifiOff, Smartphone } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { requestNotificationPermission } from '../services/audioNotification';

interface HeaderProps {
  onOpenVoiceModal: () => void;
  onOpenMorningReview: () => void;
  onOpenEveningReview: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenVoiceModal,
  onOpenMorningReview,
  onOpenEveningReview,
}) => {
  const { isInstallable, isInstalled, install, isIOS } = usePWAInstall();
  const isOnline = useOnlineStatus();
  const [notificationPerm, setNotificationPerm] = useState<NotificationPermission>('default');
  const [showIOSModal, setShowIOSModal] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      setNotificationPerm(Notification.permission);
    }
  }, []);

  const handleRequestNotifications = async () => {
    const res = await requestNotificationPermission();
    setNotificationPerm(res);
  };

  const currentHour = new Date().getHours();
  const isMorningTime = currentHour >= 5 && currentHour < 12;
  const isEveningTime = currentHour >= 18 || currentHour < 5;

  return (
    <header className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 py-3 shadow-xs">
      <div className="max-w-3xl mx-auto flex items-center justify-between gap-3">
        {/* App Title & Logo */}
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-violet-500 flex items-center justify-center text-white shadow-md shadow-indigo-500/20">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="font-bold text-base text-slate-900 dark:text-white leading-tight">
                Memory Assistant
              </h1>
              <span className="text-[10px] font-semibold uppercase tracking-wider bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 px-1.5 py-0.5 rounded-full">
                Personal
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Gentle daily companion
            </p>
          </div>
        </div>

        {/* Action Badges & Install */}
        <div className="flex items-center gap-1.5">
          {/* Offline Indicator */}
          {!isOnline && (
            <div
              className="flex items-center gap-1 bg-amber-100 dark:bg-amber-950/80 text-amber-800 dark:text-amber-300 px-2 py-1 rounded-full text-xs font-medium"
              title="Working completely offline from local storage"
            >
              <WifiOff className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Offline</span>
            </div>
          )}

          {/* Notification Permission Toggle */}
          {notificationPerm !== 'granted' && (
            <button
              onClick={handleRequestNotifications}
              className="flex items-center gap-1 text-xs font-medium bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 px-2.5 py-1.5 rounded-full hover:bg-rose-100 dark:hover:bg-rose-900 transition"
              title="Click to enable Android sound & alert notifications"
            >
              <BellOff className="w-3.5 h-3.5" />
              <span className="hidden xs:inline">Enable Alerts</span>
            </button>
          )}

          {/* Quick Review Pill based on current time */}
          {isMorningTime ? (
            <button
              onClick={onOpenMorningReview}
              className="flex items-center gap-1 text-xs font-semibold bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800/60 px-2.5 py-1.5 rounded-full hover:bg-amber-100 transition"
            >
              <span>☀️ Morning Plan</span>
            </button>
          ) : isEveningTime ? (
            <button
              onClick={onOpenEveningReview}
              className="flex items-center gap-1 text-xs font-semibold bg-indigo-50 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800/60 px-2.5 py-1.5 rounded-full hover:bg-indigo-100 transition"
            >
              <span>🌙 Evening Review</span>
            </button>
          ) : null}

          {/* PWA Install Button */}
          {isInstallable && !isInstalled && (
            <button
              onClick={install}
              className="flex items-center gap-1 text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white px-2.5 py-1.5 rounded-full shadow-sm transition active:scale-95"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Install App</span>
            </button>
          )}

          {isIOS && !isInstalled && (
            <button
              onClick={() => setShowIOSModal(true)}
              className="flex items-center gap-1 text-xs font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-2.5 py-1.5 rounded-full transition"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Install</span>
            </button>
          )}
        </div>
      </div>

      {/* iOS Installation Instruction Guide */}
      {showIOSModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-sm rounded-2xl bg-white dark:bg-slate-900 p-6 shadow-2xl border border-slate-200 dark:border-slate-800">
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Smartphone className="w-5 h-5 text-indigo-600" />
              Install on your phone
            </h3>
            <p className="mt-3 text-sm text-slate-600 dark:text-slate-300 space-y-2">
              1. Tap the <strong>Share</strong> button in your browser toolbar.<br />
              2. Scroll down and tap <strong>Add to Home Screen</strong>.<br />
              3. The app will launch in standalone native mode!
            </p>
            <button
              onClick={() => setShowIOSModal(false)}
              className="mt-5 w-full rounded-xl bg-indigo-600 text-white font-medium py-2.5 text-sm hover:bg-indigo-700 transition"
            >
              Got it
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
