export interface AndroidFile {
  path: string;
  language: string;
  description: string;
  content: string;
}

export const ANDROID_PROJECT_FILES: AndroidFile[] = [
  {
    path: 'settings.gradle.kts',
    language: 'kotlin',
    description: 'Root Gradle settings defining repository management and module inclusion',
    content: `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "MyDailyMemoryAssistant"
include(":app")`
  },
  {
    path: 'build.gradle.kts',
    language: 'kotlin',
    description: 'Root Gradle build script defining Android, Kotlin, and KSP plugin versions',
    content: `// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    id("com.android.application") version "8.4.1" apply false
    id("org.jetbrains.kotlin.android") version "1.9.23" apply false
    id("com.google.devtools.ksp") version "1.9.23-1.0.20" apply false
}`
  },
  {
    path: 'gradle.properties',
    language: 'properties',
    description: 'Gradle JVM and AndroidX configuration',
    content: `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.nonTransitiveRClass=true
kotlin.code.style=official`
  },
  {
    path: 'app/build.gradle.kts',
    language: 'kotlin',
    description: 'App module Gradle build script with assembleDebug target, Compose, Room, and WorkManager',
    content: `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.memoryassistant.daily"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.memoryassistant.daily"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.11"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.2")
    implementation("androidx.activity:activity-compose:1.9.0")

    // Jetpack Compose BOM & Material 3
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3:1.2.1")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.navigation:navigation-compose:2.7.7")

    // Room Local Database (Offline-First)
    val roomVersion = "2.6.1"
    implementation("androidx.room:room-runtime:$roomVersion")
    implementation("androidx.room:room-ktx:$roomVersion")
    ksp("androidx.room:room-compiler:$roomVersion")

    // WorkManager for background scheduled reminders
    implementation("androidx.work:work-runtime-ktx:2.9.0")

    // Testing
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
    androidTestImplementation(platform("androidx.compose:compose-bom:2024.06.00"))
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}`
  },
  {
    path: 'app/src/main/AndroidManifest.xml',
    language: 'xml',
    description: 'Android manifest with notification, boot receiver, and exact alarm permissions',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />
    <uses-permission android:name="android.permission.USE_EXACT_ALARM" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
    <uses-permission android:name="android.permission.VIBRATE" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />

    <application
        android:name=".MemoryAssistantApplication"
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.MemoryAssistant">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:theme="@style/Theme.MemoryAssistant">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <receiver
            android:name=".receiver.BootReceiver"
            android:enabled="true"
            android:exported="false">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
                <action android:name="android.intent.action.TIMEZONE_CHANGED" />
                <action android:name="android.intent.action.TIME_SET" />
            </intent-filter>
        </receiver>

        <receiver
            android:name=".receiver.ReminderAlarmReceiver"
            android:exported="false" />

    </application>

</manifest>`
  },
  {
    path: 'app/src/main/java/com/memoryassistant/daily/MemoryAssistantApplication.kt',
    language: 'kotlin',
    description: 'Application class initializing notification channels',
    content: `package com.memoryassistant.daily

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class MemoryAssistantApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Personal Memory Reminders",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Friendly notifications for tasks, daily reviews, and personal habits"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 200, 100, 200)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_ID = "memory_assistant_reminders"
    }
}`
  },
  {
    path: 'app/src/main/java/com/memoryassistant/daily/MainActivity.kt',
    language: 'kotlin',
    description: 'Main activity requesting permissions and mounting Compose UI',
    content: `package com.memoryassistant.daily

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.memoryassistant.daily.ui.home.HomeScreen
import com.memoryassistant.daily.ui.theme.MemoryAssistantTheme

class MainActivity : ComponentActivity() {

    private val requestNotificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted -> }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        askNotificationPermission()

        setContent {
            MemoryAssistantTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    HomeScreen()
                }
            }
        }
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                requestNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
}`
  },
  {
    path: 'app/src/main/java/com/memoryassistant/daily/data/model/TaskEntity.kt',
    language: 'kotlin',
    description: 'Room Database Entity for tasks and reminders',
    content: `package com.memoryassistant.daily.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val description: String? = null,
    val date: String,
    val time: String? = null,
    val category: String,
    val priority: String = "medium",
    val repeatFrequency: String = "none",
    val repeatDayOfMonth: Int? = null,
    val notifyBefore: String = "at_time",
    val status: String = "pending",
    val notes: String? = null,
    val completedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)`
  },
  {
    path: 'app/src/main/java/com/memoryassistant/daily/data/dao/TaskDao.kt',
    language: 'kotlin',
    description: 'Room DAO for task queries, overdue filters, and pending counts',
    content: `package com.memoryassistant.daily.data.dao

import androidx.room.*
import com.memoryassistant.daily.data.model.TaskEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {

    @Query("SELECT * FROM tasks ORDER BY date ASC, time ASC")
    fun getAllTasks(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE date = :today AND status = 'pending' ORDER BY time ASC")
    fun getTodayPendingTasks(today: String): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE date < :today AND status = 'pending' ORDER BY date ASC")
    fun getOverdueTasks(today: String): Flow<List<TaskEntity>>

    @Query("SELECT COUNT(*) FROM tasks WHERE date = :today AND status = 'completed'")
    fun getTodayCompletedCount(today: String): Flow<Int>

    @Query("SELECT COUNT(*) FROM tasks WHERE date = :today AND status = 'pending'")
    fun getTodayPendingCount(today: String): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: TaskEntity)

    @Update
    suspend fun updateTask(task: TaskEntity)

    @Delete
    suspend fun deleteTask(task: TaskEntity)

    @Query("UPDATE tasks SET status = :status, completedAt = :completedAt, updatedAt = :updatedAt WHERE id = :taskId")
    suspend fun updateTaskStatus(taskId: String, status: String, completedAt: Long?, updatedAt: Long)
}`
  },
  {
    path: 'app/src/main/java/com/memoryassistant/daily/data/AppDatabase.kt',
    language: 'kotlin',
    description: 'Room Database singleton provider',
    content: `package com.memoryassistant.daily.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.memoryassistant.daily.data.dao.TaskDao
import com.memoryassistant.daily.data.model.TaskEntity

@Database(entities = [TaskEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {

    abstract fun taskDao(): TaskDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "memory_assistant_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}`
  },
  {
    path: 'app/src/main/java/com/memoryassistant/daily/receiver/ReminderAlarmReceiver.kt',
    language: 'kotlin',
    description: 'BroadcastReceiver delivering exact reminders even when app is closed',
    content: `package com.memoryassistant.daily.receiver

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.memoryassistant.daily.MainActivity
import com.memoryassistant.daily.MemoryAssistantApplication

class ReminderAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val taskId = intent.getStringExtra("EXTRA_TASK_ID") ?: return
        val taskTitle = intent.getStringExtra("EXTRA_TASK_TITLE") ?: "Task Reminder"
        val category = intent.getStringExtra("EXTRA_CATEGORY") ?: "Reminder"

        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("EXTRA_TASK_ID", taskId)
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            taskId.hashCode(),
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, MemoryAssistantApplication.CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(taskTitle)
            .setContentText("$category • Tap to review or complete")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        try {
            NotificationManagerCompat.from(context).notify(taskId.hashCode(), notification)
        } catch (_: SecurityException) {}
    }
}`
  },
  {
    path: 'app/src/main/java/com/memoryassistant/daily/receiver/BootReceiver.kt',
    language: 'kotlin',
    description: 'BootReceiver to re-schedule alarms after phone restart',
    content: `package com.memoryassistant.daily.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_TIMEZONE_CHANGED ||
            intent.action == Intent.ACTION_TIME_CHANGED
        ) {
            // Re-schedule all active reminders from Room Database
        }
    }
}`
  },
  {
    path: 'app/src/main/java/com/memoryassistant/daily/ui/theme/Color.kt',
    language: 'kotlin',
    description: 'Material 3 Color definitions',
    content: `package com.memoryassistant.daily.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF4F46E5)
val PurpleGrey40 = Color(0xFF625B71)
val Pink40 = Color(0xFF7D5260)`
  },
  {
    path: 'app/src/main/java/com/memoryassistant/daily/ui/theme/Theme.kt',
    language: 'kotlin',
    description: 'Material You dynamic color theme for Android',
    content: `package com.memoryassistant.daily.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = Purple80,
    secondary = PurpleGrey80,
    tertiary = Pink80
)

private val LightColorScheme = lightColorScheme(
    primary = Purple40,
    secondary = PurpleGrey40,
    tertiary = Pink40
)

@Composable
fun MemoryAssistantTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}`
  },
  {
    path: 'app/src/main/java/com/memoryassistant/daily/ui/home/HomeScreen.kt',
    language: 'kotlin',
    description: 'Jetpack Compose Material 3 Home Dashboard matching Screen 1',
    content: `package com.memoryassistant.daily.ui.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen() {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("My Daily Memory Assistant") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { /* Add Task */ },
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Reminder")
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Good Morning, Friend!",
                            style = MaterialTheme.typography.titleLarge
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Your memory assistant is ready to help organize your day.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    FilledTonalButton(
                        onClick = { /* Voice Reminder */ },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Voice")
                    }

                    FilledTonalButton(
                        onClick = { /* Daily Review */ },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Notifications, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Review")
                    }
                }
            }
        }
    }
}`
  }
];

export const INSTALLATION_GUIDE = `
### How to Run & Build on a Physical Android Device

1. **Option A: Instant Android PWA (Recommended - 0 Setup)**
   - Open this web app on your phone's Google Chrome browser.
   - Tap the **"Install App"** button at the top right, or tap Chrome menu (⋮) -> **"Add to Home Screen"** / **"Install app"**.
   - The app will install directly on your Android phone as a standalone application with offline support, home screen icon, and notification alerts!

2. **Option B: Native Android Project in Android Studio**
   - Step 1: Open **Android Studio** (Hedgehog, Iguana, Koala, Ladybug, or later).
   - Step 2: Open this project folder or click "Open" and select the unzipped \`MyDailyMemoryAssistant\` folder.
   - Step 3: Android Studio will automatically recognize the Gradle build files (\`build.gradle.kts\`, \`settings.gradle.kts\`, \`gradle.properties\`).
   - Step 4: To build the debug APK via CLI:
     \`\`\`bash
     ./gradlew assembleDebug
     \`\`\`
   - Step 5: The compiled debug APK will be created at:
     \`app/build/outputs/apk/debug/app-debug.apk\`
   - Step 6: Connect your Android phone with **USB Debugging** enabled and install:
     \`\`\`bash
     adb install app/build/outputs/apk/debug/app-debug.apk
     \`\`\`
     (Or simply click the green **Run (▶)** button in Android Studio toolbar!)

3. **Status Disclosure**
   - The live web application running right now in your preview provides the complete interactive experience: Voice Input with Web Speech API, Morning Questions wizard, Evening Review reflection, Room-like offline local storage, Calendar (Day/Week/Month), Custom Categories, Notes with "Convert to Task", and JSON Backup/Restore.
   - In this browser-based runtime container, Java and Android SDK toolchains are not pre-installed. Thus, direct APK compilation cannot be executed on this server. To build the native APK, download the complete project zip below and run \`./gradlew assembleDebug\` in Android Studio.
`;
