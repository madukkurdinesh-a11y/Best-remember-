import { Task, UserSettings } from '../types';
import { storage } from './storage';
import { playReminderChime, triggerVibration, showSystemNotification, speakMessage } from './audioNotification';

export interface DueReminderEvent {
  task: Task;
  dueType: 'at_time' | 'before' | 'overdue';
}

type ReminderCallback = (event: DueReminderEvent) => void;
type ReviewPromptCallback = (type: 'morning' | 'evening') => void;

class SchedulerService {
  private timer: number | null = null;
  private reminderListeners: ReminderCallback[] = [];
  private reviewListeners: ReviewPromptCallback[] = [];

  public start(): void {
    if (this.timer) return;
    // Check every 10 seconds for timely notification delivery
    this.timer = window.setInterval(() => {
      this.checkDueTasks();
      this.checkReviewTimes();
    }, 10000);
    // Also run an immediate check on start
    setTimeout(() => {
      this.checkDueTasks();
      this.checkReviewTimes();
    }, 1000);
  }

  public stop(): void {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }

  public onReminder(cb: ReminderCallback): () => void {
    this.reminderListeners.push(cb);
    return () => {
      this.reminderListeners = this.reminderListeners.filter((l) => l !== cb);
    };
  }

  public onReviewPrompt(cb: ReviewPromptCallback): () => void {
    this.reviewListeners.push(cb);
    return () => {
      this.reviewListeners = this.reviewListeners.filter((l) => l !== cb);
    };
  }

  private checkDueTasks(): void {
    const tasks = storage.getTasks();
    const settings = storage.getSettings();
    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];
    const currentHours = String(now.getHours()).padStart(2, '0');
    const currentMinutes = String(now.getMinutes()).padStart(2, '0');
    const currentTimeStr = `${currentHours}:${currentMinutes}`;

    let updatedTasks = false;

    tasks.forEach((task) => {
      if (task.status !== 'pending' || !task.time) return;

      // Check if task date is today and time matches
      if (task.date === todayStr && task.time === currentTimeStr) {
        // Prevent duplicate trigger in the same minute
        const notifyKey = `${task.date}_${task.time}`;
        if (task.lastNotifiedAt === notifyKey) return;

        task.lastNotifiedAt = notifyKey;
        updatedTasks = true;

        // Feedback
        if (settings.soundEnabled) playReminderChime();
        if (settings.vibrationEnabled) triggerVibration([300, 150, 300]);
        speakMessage(`Reminder: ${task.title}`);

        showSystemNotification(`Reminder: ${task.title}`, {
          body: `${task.category} • ${task.time} • Tap to view or snooze`,
          tag: `task-${task.id}`,
        });

        this.reminderListeners.forEach((listener) => {
          listener({ task, dueType: 'at_time' });
        });
      }
    });

    if (updatedTasks) {
      storage.saveTasks(tasks);
    }
  }

  private checkReviewTimes(): void {
    const settings = storage.getSettings();
    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];
    const currentHours = String(now.getHours()).padStart(2, '0');
    const currentMinutes = String(now.getMinutes()).padStart(2, '0');
    const currentTimeStr = `${currentHours}:${currentMinutes}`;

    // Morning Review trigger
    if (currentTimeStr === settings.morningReviewTime && settings.lastMorningReviewDate !== todayStr) {
      settings.lastMorningReviewDate = todayStr;
      storage.saveSettings(settings);

      if (settings.soundEnabled) playReminderChime();
      if (settings.vibrationEnabled) triggerVibration();

      showSystemNotification('Good Morning! Time for Daily Planning', {
        body: 'Take 2 minutes to plan your day with your memory assistant.',
        tag: 'morning-review',
      });

      this.reviewListeners.forEach((l) => l('morning'));
    }

    // Evening Review trigger
    if (currentTimeStr === settings.eveningReviewTime && settings.lastEveningReviewDate !== todayStr) {
      settings.lastEveningReviewDate = todayStr;
      storage.saveSettings(settings);

      if (settings.soundEnabled) playReminderChime();
      if (settings.vibrationEnabled) triggerVibration();

      showSystemNotification('Good Evening! Time for Daily Review', {
        body: 'Review completed tasks and prepare for tomorrow with your memory assistant.',
        tag: 'evening-review',
      });

      this.reviewListeners.forEach((l) => l('evening'));
    }
  }

  /**
   * Helper to snooze a task by N minutes or to tomorrow
   */
  public snoozeTask(taskId: string, minutes: number = 10): Task | null {
    const tasks = storage.getTasks();
    const index = tasks.findIndex((t) => t.id === taskId);
    if (index === -1) return null;

    const task = tasks[index];
    const now = new Date();

    if (minutes === 1440) {
      // Tomorrow
      now.setDate(now.getDate() + 1);
      task.date = now.toISOString().split('T')[0];
    } else {
      now.setMinutes(now.getMinutes() + minutes);
      task.date = now.toISOString().split('T')[0];
      const h = String(now.getHours()).padStart(2, '0');
      const m = String(now.getMinutes()).padStart(2, '0');
      task.time = `${h}:${m}`;
    }

    task.status = 'postponed';
    task.lastNotifiedAt = undefined;
    task.updatedAt = new Date().toISOString();

    tasks[index] = task;
    storage.saveTasks(tasks);
    return task;
  }

  /**
   * Complete task and handle repetition
   */
  public completeTask(taskId: string): Task | null {
    const tasks = storage.getTasks();
    const index = tasks.findIndex((t) => t.id === taskId);
    if (index === -1) return null;

    const task = tasks[index];
    task.status = 'completed';
    task.completedAt = new Date().toISOString();
    task.updatedAt = new Date().toISOString();

    // If task repeats, create next occurrence automatically!
    if (task.repeat !== 'none') {
      const nextTask: Task = {
        ...task,
        id: `task-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        status: 'pending',
        completedAt: undefined,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        lastNotifiedAt: undefined,
      };

      const currentDate = new Date(task.date + 'T12:00:00');

      if (task.repeat === 'daily') {
        currentDate.setDate(currentDate.getDate() + 1);
        nextTask.date = currentDate.toISOString().split('T')[0];
      } else if (task.repeat === 'weekly') {
        currentDate.setDate(currentDate.getDate() + 7);
        nextTask.date = currentDate.toISOString().split('T')[0];
      } else if (task.repeat === 'monthly') {
        currentDate.setMonth(currentDate.getMonth() + 1);
        if (task.repeatDayOfMonth) {
          currentDate.setDate(Math.min(task.repeatDayOfMonth, 28));
        }
        nextTask.date = currentDate.toISOString().split('T')[0];
      } else if (task.repeat === 'yearly') {
        currentDate.setFullYear(currentDate.getFullYear() + 1);
        nextTask.date = currentDate.toISOString().split('T')[0];
      }

      tasks.unshift(nextTask);
    }

    storage.saveTasks(tasks);
    return task;
  }
}

export const schedulerService = new SchedulerService();
