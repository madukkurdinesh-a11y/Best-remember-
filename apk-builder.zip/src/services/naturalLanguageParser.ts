import { ParsedReminder, Priority, RepeatFrequency } from '../types';

function formatDate(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

export function parseReminderInput(rawInput: string): ParsedReminder {
  const text = rawInput.trim();
  const lower = text.toLowerCase();

  let title = text;
  let date: string | undefined = undefined;
  let time: string | undefined = undefined;
  let repeat: RepeatFrequency = 'none';
  let repeatDayOfMonth: number | undefined = undefined;
  let priority: Priority = 'medium';
  let category: string = 'Other';

  // 1. Detect Priority
  if (/\b(urgent|important|asap|critical|must not forget|high priority|highest)\b/i.test(lower)) {
    priority = 'high';
  } else if (/\b(low priority|whenever|if possible|optional|casual)\b/i.test(lower)) {
    priority = 'low';
  }

  // 2. Detect Repeat rules
  if (/\b(every morning|every day|daily|each day)\b/i.test(lower)) {
    repeat = 'daily';
  } else if (/\b(every week|weekly|each week)\b/i.test(lower)) {
    repeat = 'weekly';
  } else if (/\b(every month|monthly|each month)\b/i.test(lower)) {
    repeat = 'monthly';
    const dayMatch = lower.match(/\b(?:on\s+the\s+)?(\d{1,2})(?:st|nd|rd|th)?\s+(?:of\s+every\s+month|each\s+month|every\s+month)/i)
      || lower.match(/(\d{1,2})(?:st|nd|rd|th)?\s+day\s+of\s+every\s+month/i)
      || lower.match(/on\s+the\s+(\d{1,2})(?:st|nd|rd|th)?/i);
    if (dayMatch) {
      const dayNum = parseInt(dayMatch[1], 10);
      if (dayNum >= 1 && dayNum <= 31) {
        repeatDayOfMonth = dayNum;
      }
    }
  } else if (/\b(every year|annually|yearly)\b/i.test(lower)) {
    repeat = 'yearly';
  }

  // Check standalone "on the 25th" pattern
  const monthlyMatch = lower.match(/\bon\s+(?:the\s+)?(\d{1,2})(?:st|nd|rd|th)?\s+(?:of\s+every\s+month|every\s+month)\b/i);
  if (monthlyMatch) {
    repeat = 'monthly';
    repeatDayOfMonth = parseInt(monthlyMatch[1], 10);
  }

  // 3. Detect Date
  const now = new Date();
  if (/\btomorrow\b/i.test(lower)) {
    const d = new Date(now);
    d.setDate(d.getDate() + 1);
    date = formatDate(d);
  } else if (/\b(today|tonight|this afternoon|this evening|this morning)\b/i.test(lower)) {
    date = formatDate(now);
  } else if (/\bday\s+after\s+tomorrow\b/i.test(lower)) {
    const d = new Date(now);
    d.setDate(d.getDate() + 2);
    date = formatDate(d);
  } else if (/\bnext\s+(sunday|monday|tuesday|wednesday|thursday|friday|saturday)\b/i.test(lower)) {
    const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    const match = lower.match(/\bnext\s+(sunday|monday|tuesday|wednesday|thursday|friday|saturday)\b/i);
    if (match) {
      const targetDay = days.indexOf(match[1].toLowerCase());
      const currentDay = now.getDay();
      let diff = (targetDay - currentDay + 7) % 7;
      if (diff === 0) diff = 7;
      const d = new Date(now);
      d.setDate(d.getDate() + diff);
      date = formatDate(d);
    }
  } else {
    // Check specific date e.g. 25th of October, or YYYY-MM-DD
    const isoMatch = lower.match(/\b(\d{4})-(\d{2})-(\d{2})\b/);
    if (isoMatch) {
      date = isoMatch[0];
    } else if (repeat === 'monthly' && repeatDayOfMonth) {
      const currentYear = now.getFullYear();
      const currentMonth = now.getMonth();
      const d = new Date(currentYear, currentMonth, repeatDayOfMonth);
      if (d < now) {
        d.setMonth(d.getMonth() + 1);
      }
      date = formatDate(d);
    } else if (repeat === 'daily') {
      date = formatDate(now);
    }
  }

  // 4. Detect Time
  // E.g. "at 8 AM", "at 7 PM", "at 6:30 AM", "at 14:00", "tonight at 7"
  const timeMatch1 = lower.match(/\b(?:at\s+)?(\d{1,2})(?::(\d{2}))?\s*(am|pm)\b/i);
  const timeMatch2 = lower.match(/\bat\s+(\d{1,2}):(\d{2})\b/i);
  const tonightMatch = lower.match(/\btonight\s+(?:at\s+)?(\d{1,2})(?::(\d{2}))?\b/i);

  if (timeMatch1) {
    let hour = parseInt(timeMatch1[1], 10);
    const minute = timeMatch1[2] ? parseInt(timeMatch1[2], 10) : 0;
    const meridian = timeMatch1[3].toLowerCase();
    if (meridian === 'pm' && hour < 12) hour += 12;
    if (meridian === 'am' && hour === 12) hour = 0;
    time = `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
  } else if (timeMatch2) {
    const hour = parseInt(timeMatch2[1], 10);
    const minute = parseInt(timeMatch2[2], 10);
    time = `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
  } else if (tonightMatch) {
    let hour = parseInt(tonightMatch[1], 10);
    const minute = tonightMatch[2] ? parseInt(tonightMatch[2], 10) : 0;
    if (hour < 12) hour += 12;
    time = `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
  } else if (/\btonight\b/i.test(lower)) {
    time = '20:00';
  } else if (/\bevery morning\b/i.test(lower) && !time) {
    time = '07:00';
  } else if (/\bthis afternoon\b/i.test(lower) && !time) {
    time = '14:00';
  }

  // 5. Category Detection
  if (/\b(grocery|groceries|buy|supermarket|vegetable|fruit|market|store|shopping)\b/i.test(lower)) {
    category = 'Shopping';
  } else if (/\b(bill|electricity|water bill|rent|pay|subscription|fee|taxes|bank)\b/i.test(lower)) {
    category = 'Bills and payments';
  } else if (/\b(doctor|dentist|appointment|clinic|hospital|physician|checkup)\b/i.test(lower)) {
    category = 'Appointments';
  } else if (/\b(family|mom|dad|mother|father|sister|brother|kids|child|parents)\b/i.test(lower)) {
    category = 'Family';
  } else if (/\b(call|phone|message|text|email|chat|reach out|contact)\b/i.test(lower)) {
    category = 'Calls and messages';
  } else if (/\b(exercise|walk|run|gym|stretch|workout|yoga|medication|medicine|pill|vitamins)\b/i.test(lower)) {
    category = 'Health and exercise';
  } else if (/\b(birthday|anniversary|party|celebrate|gift)\b/i.test(lower)) {
    category = 'Birthdays and special dates';
  } else if (/\b(trip|travel|flight|train|errand|post office|dry clean)\b/i.test(lower)) {
    category = 'Travel and errands';
  } else if (/\b(routine|wake up|sleep|morning routine|bedtime)\b/i.test(lower)) {
    category = 'Daily routine';
  } else if (/\b(learn|read|book|study|practice|hobby|guitar)\b/i.test(lower)) {
    category = 'Learning and hobbies';
  } else if (/\b(fix|repair|clean|lawn|plants|water plant|laundry|maintenance)\b/i.test(lower)) {
    category = 'Home maintenance';
  } else if (/\b(goal|dream|resolution|habit)\b/i.test(lower)) {
    category = 'Personal goals';
  }

  // 6. Clean Title: strip leading trigger phrases
  let cleanTitle = text
    .replace(/^remind\s+me\s+to\s+/i, '')
    .replace(/^remind\s+me\s+about\s+/i, '')
    .replace(/^remind\s+me\s+/i, '')
    .replace(/^please\s+remind\s+me\s+/i, '')
    .replace(/^i\s+need\s+to\s+/i, '')
    .replace(/^don't\s+forget\s+to\s+/i, '')
    .replace(/^remember\s+to\s+/i, '');

  // Strip temporal expressions from the end or middle if matched cleanly
  cleanTitle = cleanTitle
    .replace(/\btomorrow\s+at\s+\d{1,2}(?::\d{2})?\s*(?:am|pm)?/i, '')
    .replace(/\btomorrow\b/i, '')
    .replace(/\btonight\s+at\s+\d{1,2}(?::\d{2})?\s*(?:am|pm)?/i, '')
    .replace(/\btonight\b/i, '')
    .replace(/\bevery\s+morning\s+at\s+\d{1,2}(?::\d{2})?\s*(?:am|pm)?/i, '')
    .replace(/\bon\s+(?:the\s+)?\d{1,2}(?:st|nd|rd|th)?\s+(?:of\s+every\s+month|every\s+month)/i, '')
    .replace(/\bat\s+\d{1,2}(?::\d{2})?\s*(?:am|pm)/i, '')
    .replace(/\s{2,}/g, ' ')
    .trim();

  // Capitalize first letter of title
  if (cleanTitle.length > 0) {
    cleanTitle = cleanTitle.charAt(0).toUpperCase() + cleanTitle.slice(1);
    title = cleanTitle;
  }

  // 7. Determine if follow-up question is required
  let needsFollowUp = false;
  let followUpQuestion = '';

  if (!date && repeat === 'none') {
    needsFollowUp = true;
    followUpQuestion = 'Which date should I set this reminder for? (e.g. Today, Tomorrow, or a specific date)';
  } else if (!time) {
    needsFollowUp = true;
    followUpQuestion = 'What time would you like to be reminded? (e.g. 8:00 AM, 12:00 PM, 7:00 PM)';
  }

  return {
    title: title || text,
    date,
    time,
    category,
    repeat,
    repeatDayOfMonth,
    priority,
    needsFollowUp,
    followUpQuestion,
  };
}
