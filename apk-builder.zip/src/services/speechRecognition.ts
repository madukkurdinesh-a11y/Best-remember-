/**
 * Speech Recognition service using Web Speech API (webkitSpeechRecognition)
 * with graceful error handling and real-time speech-to-text transcript.
 */

// Define SpeechRecognition types for browsers
interface IWindow extends Window {
  SpeechRecognition?: any;
  webkitSpeechRecognition?: any;
}

export interface SpeechRecognitionHandlers {
  onStart?: () => void;
  onResult: (transcript: string, isFinal: boolean) => void;
  onError?: (errorMessage: string) => void;
  onEnd?: () => void;
}

export class SpeechHelper {
  private recognition: any = null;
  private isListening: boolean = false;

  constructor() {
    if (typeof window !== 'undefined') {
      const win = window as unknown as IWindow;
      const SpeechRecognitionConstructor = win.SpeechRecognition || win.webkitSpeechRecognition;
      if (SpeechRecognitionConstructor) {
        this.recognition = new SpeechRecognitionConstructor();
        this.recognition.continuous = false;
        this.recognition.interimResults = true;
        this.recognition.lang = 'en-US';
      }
    }
  }

  public isSupported(): boolean {
    return !!this.recognition;
  }

  public startListening(handlers: SpeechRecognitionHandlers): boolean {
    if (!this.recognition) {
      if (handlers.onError) {
        handlers.onError('Speech recognition is not supported in this browser. Please use text typing instead.');
      }
      return false;
    }

    if (this.isListening) {
      this.stopListening();
    }

    this.recognition.onstart = () => {
      this.isListening = true;
      if (handlers.onStart) handlers.onStart();
    };

    this.recognition.onresult = (event: any) => {
      let interimTranscript = '';
      let finalTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscript += event.results[i][0].transcript;
        } else {
          interimTranscript += event.results[i][0].transcript;
        }
      }

      const text = finalTranscript || interimTranscript;
      handlers.onResult(text, !!finalTranscript);
    };

    this.recognition.onerror = (event: any) => {
      this.isListening = false;
      let msg = 'Voice recognition error';
      if (event.error === 'not-allowed') {
        msg = 'Microphone permission was denied. Please allow microphone access in your browser or device settings.';
      } else if (event.error === 'no-speech') {
        msg = 'No speech was detected. Please try tapping the microphone again.';
      } else if (event.error === 'network') {
        msg = 'Speech recognition network error.';
      }
      if (handlers.onError) handlers.onError(msg);
    };

    this.recognition.onend = () => {
      this.isListening = false;
      if (handlers.onEnd) handlers.onEnd();
    };

    try {
      this.recognition.start();
      return true;
    } catch (e: any) {
      this.isListening = false;
      if (handlers.onError) handlers.onError(e.message || 'Failed to start microphone');
      return false;
    }
  }

  public stopListening(): void {
    if (this.recognition && this.isListening) {
      try {
        this.recognition.stop();
      } catch {
        // Ignore
      }
      this.isListening = false;
    }
  }

  public getListeningState(): boolean {
    return this.isListening;
  }
}

export const speechService = new SpeechHelper();
