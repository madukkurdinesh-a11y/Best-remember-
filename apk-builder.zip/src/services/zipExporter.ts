import JSZip from 'jszip';
import { ANDROID_PROJECT_FILES } from '../data/androidProjectCode';

export async function downloadAndroidProjectZip(): Promise<void> {
  const zip = new JSZip();
  const rootFolder = zip.folder('MyDailyMemoryAssistant');

  if (!rootFolder) return;

  // Add all Android files
  ANDROID_PROJECT_FILES.forEach((file) => {
    rootFolder.file(file.path, file.content);
  });

  // Add README with exact instructions
  rootFolder.file(
    'README.md',
    `# My Daily Memory Assistant - Native Android Project

This is the complete, buildable native Android project using Kotlin, Jetpack Compose, Material 3, Room Local Database, and AlarmManager/WorkManager.

## How to Build the Debug APK ("assembleDebug")

1. Open this folder in **Android Studio** (Hedgehog, Iguana, Koala, Ladybug, or later).
2. Allow Android Studio to sync Gradle dependencies.
3. Open the **Terminal** tab at the bottom of Android Studio and run:
   \`\`\`bash
   ./gradlew assembleDebug
   \`\`\`
4. The compiled debug APK will be generated at:
   \`app/build/outputs/apk/debug/app-debug.apk\`
5. Install on your connected Android phone:
   \`\`\`bash
   adb install app/build/outputs/apk/debug/app-debug.apk
   \`\`\`
   Or simply click the green **Run (▶)** button in Android Studio toolbar!
`
  );

  const content = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(content);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'MyDailyMemoryAssistant-Android-Project.zip';
  a.click();
  URL.revokeObjectURL(url);
}
