import { Category } from '../types';

export const DEFAULT_CATEGORIES: Category[] = [
  { id: 'cat-daily', name: 'Daily routine', iconName: 'Sun', color: '#F59E0B', isDefault: true },
  { id: 'cat-family', name: 'Family', iconName: 'Heart', color: '#EC4899', isDefault: true },
  { id: 'cat-shopping', name: 'Shopping', iconName: 'ShoppingCart', color: '#10B981', isDefault: true },
  { id: 'cat-bills', name: 'Bills and payments', iconName: 'Receipt', color: '#3B82F6', isDefault: true },
  { id: 'cat-appointments', name: 'Appointments', iconName: 'Calendar', color: '#8B5CF6', isDefault: true },
  { id: 'cat-health', name: 'Health and exercise', iconName: 'Activity', color: '#06B6D4', isDefault: true },
  { id: 'cat-birthdays', name: 'Birthdays and special dates', iconName: 'Cake', color: '#F43F5E', isDefault: true },
  { id: 'cat-calls', name: 'Calls and messages', iconName: 'PhoneCall', color: '#0ea5e9', isDefault: true },
  { id: 'cat-travel', name: 'Travel and errands', iconName: 'Compass', color: '#F97316', isDefault: true },
  { id: 'cat-learning', name: 'Learning and hobbies', iconName: 'BookOpen', color: '#6366F1', isDefault: true },
  { id: 'cat-home', name: 'Home maintenance', iconName: 'Home', color: '#64748B', isDefault: true },
  { id: 'cat-goals', name: 'Personal goals', iconName: 'Target', color: '#14B8A6', isDefault: true },
  { id: 'cat-other', name: 'Other', iconName: 'Folder', color: '#71717A', isDefault: true },
];

export const AVAILABLE_ICONS = [
  'Sun', 'Heart', 'ShoppingCart', 'Receipt', 'Calendar',
  'Activity', 'Cake', 'PhoneCall', 'Compass', 'BookOpen',
  'Home', 'Target', 'Folder', 'Coffee', 'Music', 'Smile',
  'Sparkles', 'Bell', 'CheckCircle'
];

export const AVAILABLE_COLORS = [
  '#F59E0B', '#EC4899', '#10B981', '#3B82F6', '#8B5CF6',
  '#06B6D4', '#F43F5E', '#0EA5E9', '#F97316', '#6366F1',
  '#64748B', '#14B8A6', '#71717A', '#84CC16', '#D946EF'
];
