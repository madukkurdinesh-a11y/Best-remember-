import { Task, Category, Note, UserSettings } from '../types';
import { DEFAULT_CATEGORIES } from './categories';

const TASKS_KEY = 'mda_tasks_v1';
const CATEGORIES_KEY = 'mda_categories_v1';
const NOTES_KEY = 'mda_notes_v1';
const SETTINGS_KEY = 'mda_settings_v1';

export const DEFAULT_SETTINGS: UserSettings = {
  morningReviewTime: '07:00',
  eveningReviewTime: '20:00',
  defaultReminderTime: '09:00',
  soundEnabled: true,
  vibrationEnabled: true,
  snoozeDurationMinutes: 10,
  language: 'en',
  theme: 'system',
  userName: 'Friend',
};

function getTodayString(offsetDays = 0): string {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  return d.toISOString().split('T')[0];
}

const INITIAL_TASKS: Task[] = [
  {
    id: 'seed-task-1',
    title: 'Morning walk and light stretch',
    description: 'Breathe fresh air and do 15 minutes of gentle exercise in the park',
    date: getTodayString(0),
    time: '06:00',
    category: 'Daily routine',
    priority: 'medium',
    repeat: 'daily',
    notifyBefore: 'at_time',
    status: 'pending',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'seed-task-2',
    title: 'Call my family tonight',
    description: 'Catch up with mom and dad about the weekend',
    date: getTodayString(0),
    time: '19:00',
    category: 'Family',
    priority: 'high',
    repeat: 'none',
    notifyBefore: '15m',
    status: 'pending',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'seed-task-3',
    title: 'Buy fresh groceries',
    description: 'Milk, oats, seasonal fruits, green vegetables, and herbal tea',
    date: getTodayString(1),
    time: '08:00',
    category: 'Shopping',
    priority: 'medium',
    repeat: 'none',
    notifyBefore: 'at_time',
    status: 'pending',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'seed-task-4',
    title: 'Pay electricity & utility bill',
    description: 'Monthly utility bill payment via banking app',
    date: getTodayString(5),
    time: '10:00',
    category: 'Bills and payments',
    priority: 'high',
    repeat: 'monthly',
    repeatDayOfMonth: 25,
    notifyBefore: '1d',
    status: 'pending',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'seed-task-5',
    title: 'Dental routine checkup',
    description: 'Dr. Johnson clinic - Bring previous dental card',
    date: getTodayString(3),
    time: '14:30',
    category: 'Appointments',
    priority: 'medium',
    repeat: 'none',
    notifyBefore: '1d',
    status: 'pending',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

const INITIAL_NOTES: Note[] = [
  {
    id: 'seed-note-1',
    title: 'Doctor Advice & Medication',
    content: 'Take Vitamin D3 with breakfast. Keep hydrated with at least 2 liters of water each day.',
    isImportant: true,
    category: 'Health and exercise',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'seed-note-2',
    title: 'Favorite Birthday Gift Ideas for Sister',
    content: 'Handmade ceramic mug, warm wool scarf in pastel green, or a kindle mystery book.',
    isImportant: false,
    category: 'Birthdays and special dates',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'seed-note-3',
    title: 'House Plant Care Schedule',
    content: 'Monstera needs watering on Wednesdays and Sundays. Keep away from harsh direct midday sun.',
    isImportant: true,
    category: 'Home maintenance',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

export const storage = {
  getTasks(): Task[] {
    try {
      const raw = localStorage.getItem(TASKS_KEY);
      if (!raw) {
        localStorage.setItem(TASKS_KEY, JSON.stringify(INITIAL_TASKS));
        return INITIAL_TASKS;
      }
      return JSON.parse(raw);
    } catch {
      return INITIAL_TASKS;
    }
  },

  saveTasks(tasks: Task[]): void {
    try {
      localStorage.setItem(TASKS_KEY, JSON.stringify(tasks));
    } catch (e) {
      console.error('Failed to save tasks', e);
    }
  },

  getCategories(): Category[] {
    try {
      const raw = localStorage.getItem(CATEGORIES_KEY);
      if (!raw) {
        localStorage.setItem(CATEGORIES_KEY, JSON.stringify(DEFAULT_CATEGORIES));
        return DEFAULT_CATEGORIES;
      }
      return JSON.parse(raw);
    } catch {
      return DEFAULT_CATEGORIES;
    }
  },

  saveCategories(categories: Category[]): void {
    try {
      localStorage.setItem(CATEGORIES_KEY, JSON.stringify(categories));
    } catch (e) {
      console.error('Failed to save categories', e);
    }
  },

  getNotes(): Note[] {
    try {
      const raw = localStorage.getItem(NOTES_KEY);
      if (!raw) {
        localStorage.setItem(NOTES_KEY, JSON.stringify(INITIAL_NOTES));
        return INITIAL_NOTES;
      }
      return JSON.parse(raw);
    } catch {
      return INITIAL_NOTES;
    }
  },

  saveNotes(notes: Note[]): void {
    try {
      localStorage.setItem(NOTES_KEY, JSON.stringify(notes));
    } catch (e) {
      console.error('Failed to save notes', e);
    }
  },

  getSettings(): UserSettings {
    try {
      const raw = localStorage.getItem(SETTINGS_KEY);
      if (!raw) {
        localStorage.setItem(SETTINGS_KEY, JSON.stringify(DEFAULT_SETTINGS));
        return DEFAULT_SETTINGS;
      }
      return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
    } catch {
      return DEFAULT_SETTINGS;
    }
  },

  saveSettings(settings: UserSettings): void {
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    } catch (e) {
      console.error('Failed to save settings', e);
    }
  },

  // Export full database as JSON
  exportData(): string {
    const backup = {
      version: 1,
      appName: 'My Daily Memory Assistant',
      exportedAt: new Date().toISOString(),
      tasks: this.getTasks(),
      categories: this.getCategories(),
      notes: this.getNotes(),
      settings: this.getSettings(),
    };
    return JSON.stringify(backup, null, 2);
  },

  // Import full database from JSON
  importData(jsonString: string): { success: boolean; message: string } {
    try {
      const data = JSON.parse(jsonString);
      if (!data || (!Array.isArray(data.tasks) && !Array.isArray(data.notes))) {
        return { success: false, message: 'Invalid backup file format.' };
      }
      if (Array.isArray(data.tasks)) this.saveTasks(data.tasks);
      if (Array.isArray(data.categories)) this.saveCategories(data.categories);
      if (Array.isArray(data.notes)) this.saveNotes(data.notes);
      if (data.settings && typeof data.settings === 'object') this.saveSettings(data.settings);
      return { success: true, message: `Successfully restored ${data.tasks?.length || 0} tasks and ${data.notes?.length || 0} notes.` };
    } catch (err: unknown) {
      return { success: false, message: `Error parsing backup: ${err instanceof Error ? err.message : 'Unknown error'}` };
    }
  },

  // Reset to initial sample state
  resetAll(): void {
    localStorage.removeItem(TASKS_KEY);
    localStorage.removeItem(CATEGORIES_KEY);
    localStorage.removeItem(NOTES_KEY);
    localStorage.removeItem(SETTINGS_KEY);
  }
};
