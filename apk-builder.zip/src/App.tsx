/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Task, Category, Note, UserSettings, ActiveScreen } from './types';
import { storage } from './services/storage';
import { schedulerService } from './services/scheduler';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { ScreenHome } from './components/ScreenHome';
import { ScreenTasks } from './components/ScreenTasks';
import { ScreenCalendarNotes } from './components/ScreenCalendarNotes';
import { ScreenCategories } from './components/ScreenCategories';
import { ScreenSettings } from './components/ScreenSettings';
import { VoiceReminderModal } from './components/VoiceReminderModal';
import { MorningQuestionsModal } from './components/MorningQuestionsModal';
import { EveningReviewModal } from './components/EveningReviewModal';
import { TaskEditModal } from './components/TaskEditModal';
import { ActiveReminderAlert } from './components/ActiveReminderAlert';
import { playSuccessChime } from './services/audioNotification';

export default function App() {
  const [activeScreen, setActiveScreen] = useState<ActiveScreen>('home');
  const [tasks, setTasks] = useState<Task[]>(() => storage.getTasks());
  const [categories, setCategories] = useState<Category[]>(() => storage.getCategories());
  const [notes, setNotes] = useState<Note[]>(() => storage.getNotes());
  const [settings, setSettings] = useState<UserSettings>(() => storage.getSettings());

  // Modals state
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState(false);
  const [isAddTaskModalOpen, setIsAddTaskModalOpen] = useState(false);
  const [taskToEdit, setTaskToEdit] = useState<Task | null>(null);
  const [isMorningReviewOpen, setIsMorningReviewOpen] = useState(false);
  const [isEveningReviewOpen, setIsEveningReviewOpen] = useState(false);
  const [activeAlertTask, setActiveAlertTask] = useState<Task | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Sync with scheduler and notifications
  useEffect(() => {
    schedulerService.start();

    const unsubReminder = schedulerService.onReminder((e) => {
      setActiveAlertTask(e.task);
      setTasks(storage.getTasks()); // reload updated lastNotifiedAt
    });

    const unsubReview = schedulerService.onReviewPrompt((type) => {
      if (type === 'morning') setIsMorningReviewOpen(true);
      else setIsEveningReviewOpen(true);
    });

    return () => {
      unsubReminder();
      unsubReview();
      schedulerService.stop();
    };
  }, []);

  // Theme application
  useEffect(() => {
    const root = document.documentElement;
    if (settings.theme === 'dark') {
      root.classList.add('dark');
    } else if (settings.theme === 'light') {
      root.classList.remove('dark');
    } else {
      // System default
      if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
        root.classList.add('dark');
      } else {
        root.classList.remove('dark');
      }
    }
  }, [settings.theme]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Task actions
  const handleSaveTask = (
    taskData: Omit<Task, 'id' | 'createdAt' | 'updatedAt'>,
    id?: string
  ) => {
    const nowIso = new Date().toISOString();
    let updated: Task[];

    if (id) {
      updated = tasks.map((t) =>
        t.id === id ? { ...t, ...taskData, updatedAt: nowIso } : t
      );
      showToast('Reminder details updated.');
    } else {
      const newTask: Task = {
        ...taskData,
        id: `task-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        createdAt: nowIso,
        updatedAt: nowIso,
      };
      updated = [newTask, ...tasks];
      showToast('New reminder successfully scheduled!');
    }

    setTasks(updated);
    storage.saveTasks(updated);
    setIsAddTaskModalOpen(false);
    setTaskToEdit(null);
  };

  const handleCompleteTask = (taskId: string) => {
    const updated = schedulerService.completeTask(taskId);
    if (updated) {
      setTasks(storage.getTasks());
      playSuccessChime();
      showToast('Task marked as completed! 🎉');
    }
    if (activeAlertTask?.id === taskId) {
      setActiveAlertTask(null);
    }
  };

  const handleSnoozeTask = (taskId: string, minutes: number = 10) => {
    const snoozed = schedulerService.snoozeTask(taskId, minutes);
    if (snoozed) {
      setTasks(storage.getTasks());
      showToast(
        minutes === 1440
          ? 'Postponed to tomorrow.'
          : `Snoozed for ${minutes} minutes.`
      );
    }
    if (activeAlertTask?.id === taskId) {
      setActiveAlertTask(null);
    }
  };

  const handleDeleteTask = (taskId: string) => {
    const updated = tasks.filter((t) => t.id !== taskId);
    setTasks(updated);
    storage.saveTasks(updated);
    showToast('Reminder deleted.');
  };

  // Category actions
  const handleAddCategory = (newCat: Omit<Category, 'id' | 'isDefault'>) => {
    const cat: Category = {
      ...newCat,
      id: `cat-${Date.now()}`,
      isDefault: false,
    };
    const updated = [...categories, cat];
    setCategories(updated);
    storage.saveCategories(updated);
    showToast(`Category "${cat.name}" added.`);
  };

  const handleDeleteCategory = (categoryId: string) => {
    const updated = categories.filter((c) => c.id !== categoryId);
    setCategories(updated);
    storage.saveCategories(updated);
    showToast('Category removed.');
  };

  // Note actions
  const handleSaveNote = (
    noteData: Omit<Note, 'id' | 'createdAt' | 'updatedAt'>,
    id?: string
  ) => {
    const nowIso = new Date().toISOString();
    let updated: Note[];

    if (id) {
      updated = notes.map((n) =>
        n.id === id ? { ...n, ...noteData, updatedAt: nowIso } : n
      );
      showToast('Note updated.');
    } else {
      const newNote: Note = {
        ...noteData,
        id: `note-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        createdAt: nowIso,
        updatedAt: nowIso,
      };
      updated = [newNote, ...notes];
      showToast('Note saved to personal memory.');
    }

    setNotes(updated);
    storage.saveNotes(updated);
  };

  const handleDeleteNote = (noteId: string) => {
    const updated = notes.filter((n) => n.id !== noteId);
    setNotes(updated);
    storage.saveNotes(updated);
    showToast('Note deleted.');
  };

  const handleConvertNoteToTask = (
    note: Note,
    date: string,
    time: string,
    category: string
  ) => {
    handleSaveTask({
      title: note.title,
      description: note.content,
      date,
      time,
      category,
      priority: note.isImportant ? 'high' : 'medium',
      repeat: 'none',
      notifyBefore: 'at_time',
      status: 'pending',
    });
    showToast('Note converted to scheduled task!');
  };

  // Settings & Database reload
  const handleUpdateSettings = (newSettings: UserSettings) => {
    setSettings(newSettings);
    storage.saveSettings(newSettings);
    showToast('Preferences updated.');
  };

  const handleDataRestored = () => {
    setTasks(storage.getTasks());
    setCategories(storage.getCategories());
    setNotes(storage.getNotes());
    setSettings(storage.getSettings());
    showToast('Database successfully refreshed.');
  };

  const todayStr = new Date().toISOString().split('T')[0];
  const pendingCount = tasks.filter((t) => t.date === todayStr && t.status === 'pending').length;
  const overdueCount = tasks.filter((t) => t.date < todayStr && t.status === 'pending').length;
  const todayTasks = tasks.filter((t) => t.date === todayStr);
  const upcomingTasks = tasks.filter((t) => t.date > todayStr && t.status === 'pending');

  return (
    <div className="min-h-screen bg-slate-100/70 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors">
      {/* Top Android Material 3 App Bar */}
      <Header
        onOpenVoiceModal={() => setIsVoiceModalOpen(true)}
        onOpenMorningReview={() => setIsMorningReviewOpen(true)}
        onOpenEveningReview={() => setIsEveningReviewOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-3xl mx-auto px-4 py-4 sm:py-5">
        {activeScreen === 'home' && (
          <ScreenHome
            tasks={tasks}
            notes={notes}
            settings={settings}
            onOpenVoiceModal={() => setIsVoiceModalOpen(true)}
            onOpenAddTaskModal={() => {
              setTaskToEdit(null);
              setIsAddTaskModalOpen(true);
            }}
            onOpenMorningReview={() => setIsMorningReviewOpen(true)}
            onOpenEveningReview={() => setIsEveningReviewOpen(true)}
            onNavigateToNotes={() => setActiveScreen('notes')}
            onNavigateToTasks={() => setActiveScreen('tasks')}
            onCompleteTask={handleCompleteTask}
            onSnoozeTask={handleSnoozeTask}
          />
        )}

        {activeScreen === 'tasks' && (
          <ScreenTasks
            tasks={tasks}
            categories={categories}
            onOpenAddTaskModal={() => {
              setTaskToEdit(null);
              setIsAddTaskModalOpen(true);
            }}
            onEditTask={(task) => {
              setTaskToEdit(task);
              setIsAddTaskModalOpen(true);
            }}
            onCompleteTask={handleCompleteTask}
            onSnoozeTask={handleSnoozeTask}
            onDeleteTask={handleDeleteTask}
          />
        )}

        {activeScreen === 'calendar' && (
          <ScreenCalendarNotes
            tasks={tasks}
            notes={notes}
            categories={categories}
            onSaveNote={handleSaveNote}
            onDeleteNote={handleDeleteNote}
            onConvertNoteToTask={handleConvertNoteToTask}
            onOpenAddTaskForDate={(dateStr) => {
              setTaskToEdit({
                id: '',
                title: '',
                date: dateStr,
                time: '09:00',
                category: 'Daily routine',
                priority: 'medium',
                repeat: 'none',
                notifyBefore: 'at_time',
                status: 'pending',
                createdAt: '',
                updatedAt: '',
              });
              setIsAddTaskModalOpen(true);
            }}
          />
        )}

        {activeScreen === 'notes' && (
          <ScreenCalendarNotes
            tasks={tasks}
            notes={notes}
            categories={categories}
            onSaveNote={handleSaveNote}
            onDeleteNote={handleDeleteNote}
            onConvertNoteToTask={handleConvertNoteToTask}
            onOpenAddTaskForDate={(dateStr) => {
              setTaskToEdit({
                id: '',
                title: '',
                date: dateStr,
                time: '09:00',
                category: 'Daily routine',
                priority: 'medium',
                repeat: 'none',
                notifyBefore: 'at_time',
                status: 'pending',
                createdAt: '',
                updatedAt: '',
              });
              setIsAddTaskModalOpen(true);
            }}
          />
        )}

        {activeScreen === 'settings' && (
          <div className="space-y-6">
            <ScreenCategories
              categories={categories}
              tasks={tasks}
              onAddCategory={handleAddCategory}
              onDeleteCategory={handleDeleteCategory}
              onSelectCategoryFilter={(catName) => {
                setActiveScreen('tasks');
              }}
            />

            <ScreenSettings
              settings={settings}
              onUpdateSettings={handleUpdateSettings}
              onDataRestored={handleDataRestored}
            />
          </div>
        )}
      </main>

      {/* Material 3 Bottom Navigation Bar */}
      <BottomNav
        activeScreen={activeScreen}
        onSelectScreen={setActiveScreen}
        pendingCount={pendingCount}
        overdueCount={overdueCount}
      />

      {/* Voice & Text Reminder Modal (Screen 2) */}
      <VoiceReminderModal
        isOpen={isVoiceModalOpen}
        onClose={() => setIsVoiceModalOpen(false)}
        categories={categories}
        onSaveTask={(newTask) => handleSaveTask(newTask)}
      />

      {/* Morning Questions Flow (Screen 3) */}
      <MorningQuestionsModal
        isOpen={isMorningReviewOpen}
        onClose={() => setIsMorningReviewOpen(false)}
        categories={categories}
        existingTodayTasks={todayTasks}
        onConfirmPlan={(newTasks) => {
          newTasks.forEach((t) => handleSaveTask(t));
          showToast(`Morning plan confirmed with ${newTasks.length} tasks!`);
        }}
      />

      {/* Evening Review Flow (Screen 4) */}
      <EveningReviewModal
        isOpen={isEveningReviewOpen}
        onClose={() => setIsEveningReviewOpen(false)}
        todayTasks={todayTasks}
        upcomingTasks={upcomingTasks}
        onCompleteTask={handleCompleteTask}
        onPostponeTask={handleSnoozeTask}
        onAddNewTask={(newTask) => handleSaveTask(newTask)}
      />

      {/* Create / Edit Task Modal */}
      <TaskEditModal
        isOpen={isAddTaskModalOpen}
        onClose={() => {
          setIsAddTaskModalOpen(false);
          setTaskToEdit(null);
        }}
        categories={categories}
        taskToEdit={taskToEdit}
        onSave={handleSaveTask}
      />

      {/* Active Alarm Modal when a reminder is due */}
      <ActiveReminderAlert
        task={activeAlertTask}
        snoozeMinutes={settings.snoozeDurationMinutes}
        onComplete={handleCompleteTask}
        onSnooze={handleSnoozeTask}
        onDismiss={() => setActiveAlertTask(null)}
      />

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 bg-slate-900/90 dark:bg-white/95 text-white dark:text-slate-900 px-4 py-2.5 rounded-2xl text-xs font-semibold shadow-xl border border-white/10 dark:border-slate-800 animate-in fade-in slide-in-from-bottom-2 duration-200">
          {toastMessage}
        </div>
      )}
    </div>
  );
}
