export type Priority = 'low' | 'medium' | 'high';

export type TaskStatus = 'pending' | 'completed' | 'postponed';

export type RepeatFrequency = 'none' | 'daily' | 'weekly' | 'monthly' | 'yearly';

export type NotifyBefore = 'none' | 'at_time' | '15m' | '1h' | '1d';

export interface Task {
  id: string;
  title: string;
  description?: string;
  date: string; // YYYY-MM-DD
  time?: string; // HH:mm (24h)
  category: string;
  priority: Priority;
  repeat: RepeatFrequency;
  repeatDayOfMonth?: number; // 1-31 for monthly repeats
  notifyBefore: NotifyBefore;
  status: TaskStatus;
  completedAt?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
  lastNotifiedAt?: string;
}

export interface Category {
  id: string;
  name: string;
  iconName: string;
  color: string;
  isDefault: boolean;
}

export interface Note {
  id: string;
  title: string;
  content: string;
  isImportant: boolean;
  category?: string;
  createdAt: string;
  updatedAt: string;
}

export interface UserSettings {
  morningReviewTime: string; // "07:00"
  eveningReviewTime: string; // "20:00"
  defaultReminderTime: string; // "09:00"
  soundEnabled: boolean;
  vibrationEnabled: boolean;
  snoozeDurationMinutes: number; // 5, 10, 15, 30, 60
  language: string;
  theme: 'system' | 'light' | 'dark';
  userName: string;
  lastMorningReviewDate?: string; // YYYY-MM-DD
  lastEveningReviewDate?: string; // YYYY-MM-DD
}

export interface ParsedReminder {
  title: string;
  date?: string;
  time?: string;
  category?: string;
  repeat?: RepeatFrequency;
  repeatDayOfMonth?: number;
  priority?: Priority;
  needsFollowUp?: boolean;
  followUpQuestion?: string;
}

export type ActiveScreen = 'home' | 'tasks' | 'calendar' | 'notes' | 'settings';
